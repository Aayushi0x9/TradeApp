package com.example.paper_trading

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

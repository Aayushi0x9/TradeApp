
import 'package:base_code/module/bottom/bottom_screen.dart';
import 'package:base_code/module/bottom/chart/chart_screen.dart';
import 'package:base_code/module/login/login_screen.dart';
import 'package:base_code/package/screen_packages.dart';
import 'module/bottom/profile/support_screen.dart';
import 'module/bottom/stock trading/stock_trading_screen.dart';
import 'package/config_packages.dart';

class AppRouter {
  static const splash = '/splash';
  static const bottomBarScreen = '/bottomBarScreen';
  static const loginScreen = '/loginScreen';
  static const detailScreen = '/detailScreen';
  static const chartScreen = '/chartScreen';
  static const supportScreen = '/supportScreen';


  static List<GetPage> getPages = [
    GetPage(name: splash, page: () => SplashScreen()),
    GetPage(name: bottomBarScreen, page: () =>  BottomBarScreen()),
    GetPage(name: loginScreen, page: () =>  const LoginScreen()),
    GetPage(name: detailScreen, page: () =>   const StockTradingScreen()),
    GetPage(name: chartScreen, page: () =>    const ChartScreen()),
    GetPage(name: supportScreen, page: () =>    const SupportScreen()),


  ];
}

import 'dart:async';
import 'dart:convert';
import 'package:get/get.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

import 'data/pref/app_preferences.dart';
import 'package/config_packages.dart';

class GlobalController extends GetxController with WidgetsBindingObserver {
  static WebSocketChannel? socket;
  RxMap<int, double> marketPrices = <int, double>{}.obs;
  RxMap<int, double> marketClosePrices = <int, double>{}.obs;
  bool isConnecting = false;
  bool isConnected = false;
  List<int> subscribedTokens = [];
  List<int> pendingSubscriptions = [];
  Timer? _reconnectTimer;
  StreamSubscription? _streamSubscription;

  @override
  void onInit() {
    super.onInit();
    WidgetsBinding.instance.addObserver(this);
    if (AppPref().isLogin) {
      connectSocket();
    }
  }

  @override
  void onClose() {
    WidgetsBinding.instance.removeObserver(this);
    _closeSocket();
    _reconnectTimer?.cancel();
    super.onClose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    print("App Lifecycle State: $state");
    if (state == AppLifecycleState.resumed && AppPref().isLogin) {
      if (!isConnected && !isConnecting) {
        print("App Resumed - Reconnecting WebSocket...");
        connectSocket();
      }
    } else if (state == AppLifecycleState.paused) {
      print("App Paused - Closing WebSocket...");
      unsubscribeFromTokens(subscribedTokens);
      _closeSocket();
    }
  }

  Future<void> connectSocket() async {
    if (isConnecting || isConnected) {
      print("WebSocket already connecting or connected. Skipping...");
      return;
    }

    _closeSocket();
    isConnecting = true;
    try {
      print("Attempting to connect to WebSocket...");
      socket = WebSocketChannel.connect(Uri.parse("ws://serve.indifunded.com"));

      // Implement custom timeout for connection
      await socket!.ready.timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          throw TimeoutException("WebSocket connection timed out after 10 seconds");
        },
      );

      isConnecting = false;
      isConnected = true;

      print('Connected to WebSocket');

      // Set up stream listener
      _streamSubscription?.cancel();
      _streamSubscription = socket!.stream.listen(
            (event) {
          print("WebSocket event: $event");
          _handleSocketData(event);
        },
        onDone: () {
          print('WebSocket closed. Attempting to reconnect...');
          isConnected = false;
          _scheduleReconnect();
        },
        onError: (error) {
          print('WebSocket error: $error. Attempting to reconnect...');
          isConnected = false;
          _scheduleReconnect();
        },
        cancelOnError: true,
      );

      // Process pending subscriptions
      if (pendingSubscriptions.isNotEmpty) {
        print("Processing pending subscriptions: $pendingSubscriptions");
        subscribeToTokens(pendingSubscriptions);
        pendingSubscriptions.clear();
      }
    } catch (e) {
      print("WebSocket connection exception: $e");
      isConnecting = false;
      isConnected = false;
      _scheduleReconnect();
    }
  }

  void _scheduleReconnect() {
    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(const Duration(seconds: 5), () {
      if (!isConnected && !isConnecting && AppPref().isLogin) {
        connectSocket();
      }
    });
  }

  void _closeSocket() {
    _streamSubscription?.cancel();
    _streamSubscription = null;
    if (socket != null) {
      socket!.sink.close();
      socket = null;
    }
    isConnected = false;
    isConnecting = false;
  }

  void unsubscribeFromTokens(List<int> tokens) {
    if (socket != null && isConnected && tokens.isNotEmpty) {
      final data = {"a": "unsubscribe", "v": tokens};
      String jsonData = jsonEncode(data);
      socket!.sink.add(jsonData);
      print("Sent unsubscription: $jsonData");
    } else {
      print("WebSocket is not open or no tokens to unsubscribe.");
    }
  }

  void _handleSocketData(dynamic event) {
    print("Raw WebSocket event: $event");
    try {
      final List<dynamic> messages = jsonDecode(event);
      print("Parsed messages: $messages");
      for (var item in messages) {
        final int? token = item["instrumentToken"];
        final double lastTradedPrice = (item["lastTradedPrice"] as num?)?.toDouble() ?? 0.0;
        final double closePrice = (item["closePrice"] as num?)?.toDouble() ?? 0.0;

        if (token != null && lastTradedPrice > 0) {
          marketPrices[token] = lastTradedPrice;
          marketClosePrices[token] = closePrice;
          print("Updated price for token $token: $lastTradedPrice, close: $closePrice");
        } else {
          print("Invalid data for item: $item");
        }
      }
    } catch (e) {
      print("Error parsing WebSocket event: $e, raw event: $event");
    }
  }

  void subscribeToTokens(List<int> tokens) {
    if (tokens.isEmpty) {
      print("No tokens to subscribe to.");
      return;
    }

    if (socket != null && isConnected) {
      final data = {"a": "subscribe", "v": tokens};
      String jsonData = jsonEncode(data);
      socket!.sink.add(jsonData);
      print("Sent subscription: $jsonData");
      subscribedTokens = tokens;
    } else {
      print("WebSocket not open. Queuing subscription for tokens: $tokens");
      pendingSubscriptions = tokens;
      if (!isConnecting && !isConnected && AppPref().isLogin) {
        connectSocket();
      }
    }
  }
}
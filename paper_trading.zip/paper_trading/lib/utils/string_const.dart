class StringConst{

  static const soulContactEmail = "support@soulcard.co";
  static String fontFamily = "Poppins";


}
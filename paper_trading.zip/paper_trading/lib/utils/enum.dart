enum ButtonType { enable, disable, progress }

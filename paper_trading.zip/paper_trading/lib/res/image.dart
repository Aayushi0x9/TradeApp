

class  AppImage{



 static const images = "asset/image/";
 static const dashboard = "${images}bottomBar/";
 static const appLogo = "${images}appLogo/";
 static const icons = "${images}icons/";


// app logo
 static const appIcon = "${appLogo}appLogo.png";
 static const splashIcon = "${appLogo}splash.png";
 static const lists = "${appLogo}lists.png";
 static const briefcase = "${appLogo}briefcase.png";
 static const profile = "${appLogo}profile.png";
 static const indifunded = "${appLogo}indifunded.png";
 static const tata = "${appLogo}tata.png";


// dashboard icon


 //icons





}
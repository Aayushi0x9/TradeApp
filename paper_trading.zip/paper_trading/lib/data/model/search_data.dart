
class SearchData {
  bool? success;
  int? statusCode;
  String? message;
  List<SearchAllData>? data;

  SearchData({this.success, this.statusCode, this.message, this.data});

  SearchData.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    statusCode = json['statusCode'];
    message = json['message'];
    if (json['data'] != null) {
      data = <SearchAllData>[];
      json['data'].forEach((v) {
        data!.add(SearchAllData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['statusCode'] = statusCode;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SearchAllData {
  int? instrumentToken;
  int? exchangeToken;
  String? tradingsymbol;
  String? name;
  double? lastPrice; // Change from int? to double?
  String? expiry;
  int? strike;
  double? tickSize;
  int? lotSize;
  String? instrumentType;
  String? segment;
  String? exchange;

  SearchAllData(
      {this.instrumentToken,
        this.exchangeToken,
        this.tradingsymbol,
        this.name,
        this.lastPrice,
        this.expiry,
        this.strike,
        this.tickSize,
        this.lotSize,
        this.instrumentType,
        this.segment,
        this.exchange});

  SearchAllData.fromJson(Map<String, dynamic> json) {
    instrumentToken = json['instrument_token'];
    exchangeToken = json['exchange_token'];
    tradingsymbol = json['tradingsymbol'];
    name = json['name'];
    lastPrice = (json['last_price'] as num?)?.toDouble(); // Convert to double
    expiry = json['expiry'];
    strike = json['strike'];
    tickSize = (json['tick_size'] as num?)?.toDouble();
    lotSize = json['lot_size'];
    instrumentType = json['instrument_type'];
    segment = json['segment'];
    exchange = json['exchange'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['instrument_token'] = instrumentToken;
    data['exchange_token'] = exchangeToken;
    data['tradingsymbol'] = tradingsymbol;
    data['name'] = name;
    data['last_price'] = lastPrice;
    data['expiry'] = expiry;
    data['strike'] = strike;
    data['tick_size'] = tickSize;
    data['lot_size'] = lotSize;
    data['instrument_type'] = instrumentType;
    data['segment'] = segment;
    data['exchange'] = exchange;
    return data;
  }
}
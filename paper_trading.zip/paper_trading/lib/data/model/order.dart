class OrderData {
  bool? success;
  int? statusCode;
  String? message;
  List<OrderDetails>? data;

  OrderData({this.success, this.statusCode, this.message, this.data});

  OrderData.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    statusCode = json['statusCode'];
    message = json['message'];
    if (json['data'] != null) {
      data = (json['data'] as List).map((e) => OrderDetails.fromJson(e)).toList();
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'statusCode': statusCode,
      'message': message,
      'data': data?.map((e) => e.toJson()).toList(),
    };
  }
}

class OrderDetails {
  String? id;
  String? status;
  int? instrumentId;
  String? tradingsymbol;
  String? name;
  String? exchange;
  double? price;
  int? quantity;
  int? lotSize;
  String? expiry;
  String? instrumentType;
  String? orderType;
  String? buyType;
  String? showType;
  double? buyPrice;
  String? user;
  String? createdAt;
  String? updatedAt;
  int? version;

  OrderDetails({
    this.id,
    this.status,
    this.instrumentId,
    this.tradingsymbol,
    this.name,
    this.exchange,
    this.price,
    this.quantity,
    this.lotSize,
    this.expiry,
    this.instrumentType,
    this.orderType,
    this.buyType,
    this.showType,
    this.buyPrice,
    this.user,
    this.createdAt,
    this.updatedAt,
    this.version,
  });

  OrderDetails.fromJson(Map<String, dynamic> json) {
    id = json['_id'];
    status = json['status'];
    instrumentId = json['instrument_id'];
    tradingsymbol = json['tradingsymbol'];
    name = json['name'];
    exchange = json['exchange'];
    price = double.tryParse(json['price'].toString());
    quantity = json['quantity'] != null ? int.tryParse(json['quantity'].toString()) : null;
    lotSize = json['lot_size'] ?? 0;
    expiry = json['expiry'] ?? "";
    instrumentType = json['instrument_type'];
    orderType = json['order_type'] ?? "market";
    buyType = json['buy_type'];
    showType = json['show_type'];
    buyPrice = json['buy_price'] != null ? double.tryParse(json['buy_price'].toString()) : null;
    user = json['user'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    version = json['__v'];
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'status': status,
      'instrument_id': instrumentId,
      'tradingsymbol': tradingsymbol,
      'name': name,
      'exchange': exchange,
      'price': price?.toStringAsFixed(2),
      'quantity': quantity,
      'lot_size': lotSize,
      'expiry': expiry,
      'instrument_type': instrumentType,
      'order_type': orderType,
      'buy_type': buyType,
      'show_type': showType,
      'buy_price': buyPrice?.toStringAsFixed(2),
      'user': user,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      '__v': version,
    };
  }
}
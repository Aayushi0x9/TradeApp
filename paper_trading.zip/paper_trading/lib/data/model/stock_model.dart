
class StockData {
  final String? status;
  final List<StockCandle>? candles;

  StockData({ this.status,  this.candles});

  factory StockData.fromJson(Map<String, dynamic> json) {
    return StockData(
      status: json["status"],
      candles: (json["data"]["candles"] as List)
          .map((candle) => StockCandle.fromJson(candle))
          .toList(),
    );
  }
}

class StockCandle {
  final DateTime time;
  final double open;
  final double high;
  final double low;
  final double close;
  final int volume;

  StockCandle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });

  factory StockCandle.fromJson(List<dynamic> json) {
    return StockCandle(
      time: DateTime.parse(json[0]),
      open: json[1].toDouble(),
      high: json[2].toDouble(),
      low: json[3].toDouble(),
      close: json[4].toDouble(),
      volume: json[5].toInt(),
    );
  }


}

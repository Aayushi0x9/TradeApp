class PositionData {
  final bool success;
  final int statusCode;
  final String message;
  final List<InstrumentData> data;

  PositionData({
    required this.success,
    required this.statusCode,
    required this.message,
    required this.data,
  });

  /// Update this method to accept a Map instead of a String
  factory PositionData.fromJson(Map<String, dynamic> json) => PositionData(
    success: json["success"] ?? false,
    statusCode: json["statusCode"] ?? 0,
    message: json["message"] ?? "",
    data: json["data"] != null
        ? List<InstrumentData>.from(
        json["data"].map((x) => InstrumentData.fromJson(x)))
        : [],
  );
}

class InstrumentData {
  final int instrumentId;
  final int quantity;
  final int? totalLot; // Nullable
  final String price;
  final String tradingSymbol;
  final String name;
  final String exchange;
  final String instrumentType;
  final String buyType;
  final String createdAt; // Added field
  final String id; // Added field

  InstrumentData({
    required this.instrumentId,
    required this.quantity,
    this.totalLot, // Nullable
    required this.price,
    required this.tradingSymbol,
    required this.name,
    required this.exchange,
    required this.instrumentType,
    required this.buyType,
    required this.createdAt,
    required this.id,
  });

  factory InstrumentData.fromJson(Map<String, dynamic> json) => InstrumentData(
    instrumentId: json["instrument_id"] ?? 0,
    quantity: json['quantity'] != null ? int.tryParse(json['quantity'].toString()) ?? 0 : 0,
    totalLot: json["instrument_type"] == "EQ" ? null : json["total_lot"],
    price: json["price"] ?? "0.0",
    tradingSymbol: json["tradingsymbol"] ?? "",
    name: json["name"] ?? "",
    exchange: json["exchange"] ?? "",
    instrumentType: json["instrument_type"] ?? "",
    buyType: json["buy_type"] ?? "",
    createdAt: json["createdAt"] ?? "",
    id: json["_id"] ?? "",
  );
}

class PortfolioData {
  bool? success;
  int? statusCode;
  String? message;
  List<PortfolioAllData>? data;
  PortfolioData({this.success, this.statusCode, this.message, this.data});
  PortfolioData.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    statusCode = json['statusCode'];
    message = json['message'];
    if (json['data'] != null) {
      data = <PortfolioAllData>[];
      json['data'].forEach((v) {
        data!.add(PortfolioAllData.fromJson(v));
      });
    }
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['statusCode'] = statusCode;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
class PortfolioAllData {
  int? instrumentId;
  int? quantity;
  String? avgPrice;
  String? tradingsymbol;
  String? name;
  String? exchange;
  PortfolioAllData(
      {this.instrumentId,
        this.quantity,
        this.avgPrice,
        this.tradingsymbol,
        this.name,
        this.exchange});
  PortfolioAllData.fromJson(Map<String, dynamic> json) {
    instrumentId = json['instrument_id'];
    quantity = json['quantity'];
    avgPrice = json['avgPrice'];
    tradingsymbol = json['tradingsymbol'];
    name = json['name'];
    exchange = json['exchange'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['instrument_id'] = instrumentId;
    data['quantity'] = quantity;
    data['avgPrice'] = avgPrice;
    data['tradingsymbol'] = tradingsymbol;
    data['name'] = name;
    data['exchange'] = exchange;
    return data;
  }
}
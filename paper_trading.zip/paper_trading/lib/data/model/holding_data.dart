class HoldingData {
  bool? success;
  int? statusCode;
  String? message;
  List<HoldingAllData>? data;

  HoldingData({this.success, this.statusCode, this.message, this.data});

  HoldingData.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    statusCode = json['statusCode'];
    message = json['message'];
    if (json['data'] != null) {
      data = <HoldingAllData>[];
      json['data'].forEach((v) {
        data!.add(HoldingAllData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['statusCode'] = statusCode;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class HoldingAllData {
  int? instrumentId;
  int? quantity;
  String? price;
  int? totalLot;
  String? tradingsymbol;
  String? name;
  String? exchange;
  String? instrumentType;
  String? buyType;
  String? createdAt;
  String? id;

  HoldingAllData({
    this.instrumentId,
    this.quantity,
    this.price,
    this.totalLot,
    this.tradingsymbol,
    this.name,
    this.exchange,
    this.instrumentType,
    this.buyType,
    this.createdAt,
    this.id,
  });

  HoldingAllData.fromJson(Map<String, dynamic> json) {
    instrumentId = json['instrument_id'];
    quantity = json['quantity'] != null ? int.tryParse(json['quantity'].toString()) : null;
    price = json['price'];
    totalLot = json['total_lot'];
    tradingsymbol = json['tradingsymbol'];
    name = json['name'];
    exchange = json['exchange'];
    instrumentType = json['instrument_type'];
    buyType = json['buy_type'];
    createdAt = json['createdAt'];
    id = json['_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['instrument_id'] = instrumentId;
    data['quantity'] = quantity;
    data['price'] = price;
    data['total_lot'] = totalLot;
    data['tradingsymbol'] = tradingsymbol;
    data['name'] = name;
    data['exchange'] = exchange;
    data['instrument_type'] = instrumentType;
    data['buy_type'] = buyType;
    data['createdAt'] = createdAt;
    data['_id'] = id;
    return data;
  }
}

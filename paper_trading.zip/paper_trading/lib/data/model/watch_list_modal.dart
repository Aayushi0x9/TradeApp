class WatchListData {
  bool? success;
  int? statusCode;
  String? message;
  List<WatchListModalData>? data;

  WatchListData({this.success, this.statusCode, this.message, this.data});

  WatchListData.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    statusCode = json['statusCode'];
    message = json['message'];
    if (json['data'] != null) {
      data = <WatchListModalData>[];
      json['data'].forEach((v) {
        data!.add(WatchListModalData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['success'] = success;
    data['statusCode'] = statusCode;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class WatchListModalData {
  String? sId;
  int? instrumentToken;
  String? tradingsymbol;
  String? exchange;       // ✅ Added missing field
  String? instrumentType; // ✅ Added missing field
  String? name;
  String? user;
  String? wishlistName;
  String? createdAt;
  String? updatedAt;
  int? iV;

  WatchListModalData({
    this.sId,
    this.instrumentToken,
    this.tradingsymbol,
    this.exchange,       // ✅ Added
    this.instrumentType, // ✅ Added
    this.name,
    this.user,
    this.wishlistName,
    this.createdAt,
    this.updatedAt,
    this.iV
  });

  WatchListModalData.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    instrumentToken = json['instrument_token'];
    tradingsymbol = json['tradingsymbol'];
    exchange = json['exchange'];         // ✅ Added
    instrumentType = json['instrument_type']; // ✅ Added
    name = json['name'];
    user = json['user'];
    wishlistName = json['wishlist_name'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['instrument_token'] = instrumentToken;
    data['tradingsymbol'] = tradingsymbol;
    data['exchange'] = exchange;         // ✅ Added
    data['instrument_type'] = instrumentType; // ✅ Added
    data['name'] = name;
    data['user'] = user;
    data['wishlist_name'] = wishlistName;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['__v'] = iV;
    return data;
  }
}

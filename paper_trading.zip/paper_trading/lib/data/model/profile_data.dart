class ProfileData {
  bool? success;
  int? statusCode;
  String? message;
  List<Data>? data; // Change to List<Data>

  ProfileData({this.success, this.statusCode, this.message, this.data});

  ProfileData.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    statusCode = json['statusCode'];
    message = json['message'];
    if (json['data'] != null) {
      if (json['data'] is List) {
        data = (json['data'] as List).map((e) => Data.fromJson(e)).toList();
      } else if (json['data'] is Map<String, dynamic>) {
        data = [Data.fromJson(json['data'])]; // Convert single object to List
      }
    }

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = {};
    data['success'] = success;
    data['statusCode'] = statusCode;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}


class Data {
  String? sId;
  String? email;
  String? name;
  num? walletBalance; // Use `num` to support both int and double

  Data({this.sId, this.email, this.name, this.walletBalance});

  Data.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    email = json['email'];
    name = json['name'];
    walletBalance = json['walletBalance'] != null ? json['walletBalance'].toDouble() : 0;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['email'] = email;
    data['name'] = name;
    data['walletBalance'] = walletBalance;
    return data;
  }
}
class ExecutedData {
  bool? success;
  int? statusCode;
  String? message;
  List<ExecutedAllData>? data;

  ExecutedData({this.success, this.statusCode, this.message, this.data});

  ExecutedData.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    statusCode = json['statusCode'];
    message = json['message'];
    if (json['data'] != null) {
      data = (json['data'] as List)
          .map((e) => ExecutedAllData.fromJson(e))
          .toList();
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'statusCode': statusCode,
      'message': message,
      'data': data?.map((e) => e.toJson()).toList(),
    };
  }
}

class ExecutedAllData {
  String? id;
  int? instrumentId;
  int? quantity;
  String? status;
  double? price;
  int? totalLot;
  int? totalLotCalculation;
  String? tradingsymbol;
  String? showType;
  String? name;
  String? exchange;
  String? instrumentType;
  String? buyType;
  String? createdAt;
  String? orderType;
  String? updatedAt;
  double? buyPrice;

  ExecutedAllData({
    this.id,
    this.instrumentId,
    this.quantity,
    this.status,
    this.price,
    this.totalLot,
    this.totalLotCalculation,
    this.tradingsymbol,
    this.showType,
    this.name,
    this.exchange,
    this.instrumentType,
    this.buyType,
    this.createdAt,
    this.orderType,
    this.updatedAt,
    this.buyPrice,
  });

  ExecutedAllData.fromJson(Map<String, dynamic> json) {
    id = json['_id'];
    instrumentId = json['instrument_id'];
    quantity = json['quantity'] != null ? int.tryParse(json['quantity'].toString()) : null;
    status = json['status'];
    price = double.tryParse(json['price']?.toString() ?? '0.0');
    totalLot = json['total_lot'];
    totalLotCalculation = json['total_lot_calculation'] ?? 0;
    tradingsymbol = json['tradingsymbol'];
    showType = json['show_type'];
    name = json['name'];
    exchange = json['exchange'];
    instrumentType = json['instrument_type'];
    buyType = json['buy_type'];
    createdAt = json['createdAt'];
    orderType = json['order_type'] ?? "market";
    updatedAt = json['updatedAt'];
    buyPrice = json['buy_price'] != null ? double.tryParse(json['buy_price'].toString()) : null;
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'instrument_id': instrumentId,
      'quantity': quantity,
      'status': status,
      'price': price?.toStringAsFixed(2),
      'total_lot': totalLot,
      'total_lot_calculation': totalLotCalculation,
      'tradingsymbol': tradingsymbol,
      'show_type': showType,
      'name': name,
      'exchange': exchange,
      'instrument_type': instrumentType,
      'buy_type': buyType,
      'createdAt': createdAt,
      'order_type': orderType,
      'updatedAt': updatedAt,
      'buy_price': buyPrice?.toStringAsFixed(2),
    };
  }
}

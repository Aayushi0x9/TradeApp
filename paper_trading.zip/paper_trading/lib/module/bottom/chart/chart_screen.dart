import 'package:base_code/components/common_appbar.dart';
import 'package:base_code/module/bottom/chart/chart_controller.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:interactive_chart/interactive_chart.dart';

class ChartScreen extends StatefulWidget {
  const ChartScreen({super.key});

  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  final controller = Get.put<ChartController>(ChartController());
  @override
  void initState() {
    super.initState();
    final arguments = Get.arguments as Map<String, dynamic>?;
    int? token = arguments?['token'];

    if (token != null) {
      controller.token.value = token;
      controller.fetchData();
      controller.startAutoRefresh(); // Start periodic refresh
    }
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: CommonAppBar(
        title: const Text("Chart"),
        showFilterIcon: false,
      ),
      body: Column(
        children: [
          Obx(() => DropdownButton<String>(
            value: controller.selectedInterval.value,
            onChanged: (newValue) {
              if (newValue != null) {
                controller.setInterval(newValue);
              }
            },
            items: [
              'minute',
              'day',
              '3minute',
              '5minute',
              '10minute',
              '15minute',
              '30minute',
              '60minute'
            ]                .map((interval) => DropdownMenuItem(
              value: interval,
              child: Text(interval.capitalizeFirst!),
            ))
                .toList(),
          )),
          Obx(()=> (controller.graphData).isNotEmpty?
            SizedBox(
                height: 400,
                child: InteractiveChart(


                  candles: controller.graphData,
                )
            ): const SizedBox(
              height: 400,
              child: Center(
                child: Text("loading data..."),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:base_code/package/config_packages.dart';
import 'package:base_code/data/model/stock_model.dart';
import 'package:base_code/data/network/api_client.dart';
import 'package:base_code/data/network/dio_client.dart';
import 'package:interactive_chart/interactive_chart.dart';
class ChartController extends GetxController{
  Rx<StockData> stockData = Rx<StockData>(StockData());
  final RxList<CandleData> graphData = <CandleData>[].obs ;
  Timer? _timer;
  RxString selectedInterval = 'minute'.obs;
  RxInt token = 0.obs;
  void setInterval(String newInterval) {
    selectedInterval.value = newInterval;
    graphData.clear();
    getShareData(token.value);
  }
  void fetchData() async {
    if (token.value != 0) {
      await getShareData(token.value); // Just await, don't assign to a variable
    }
  }

  @override
  void onInit() {
    super.onInit();
    if (token.value != 0) {
      fetchData();
      startAutoRefresh();
    }
  }
  void startAutoRefresh() {
    _timer?.cancel(); // Cancel any existing timer
    _timer = Timer.periodic(const Duration(seconds: 5), (timer) {
      fetchData(); // Fetch latest data every 5 seconds
    });
  }
  Future<void> getShareData(int token) async {
    try {
      String fromDate = DateTime.now().subtract(const Duration(days:60)).toString().split('.')[0];
      String toDate = DateTime.now().toString().split('.')[0];
      final response = await callApi(
        dio.get('${baseUrl}historical?instrumentToken=$token&from=$fromDate&to=$toDate&interval=${selectedInterval.value}'),
        false,
      );
      if (response?.statusCode == 200) {
        stockData.value = StockData.fromJson(response?.data);
        ConvertData convertData = ConvertData(rawData: response?.data["data"]["candles"]);
        graphData.value = convertData.candles ;
      }
    } catch (dioError) {
      print(dioError);
    }
  }

}
class ConvertData {
  List<dynamic> rawData = [];
  ConvertData({required this.rawData});
  List<CandleData> get candles => rawData.map((row) => CandleData(
    timestamp: DateTime.parse(row[0]).millisecondsSinceEpoch,
    open: row[1]?.toDouble(),
    high: row[2]?.toDouble(),
    low: row[3]?.toDouble(),
    close: row[4]?.toDouble(),
    volume: row[5]?.toDouble(),
  )).toList();
}
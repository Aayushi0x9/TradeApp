import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});

  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  final String whatsappNumber = "9081322257";

  final List<String> callSupportNumbers = ["9081322258", "9081322259"];

  final String supportEmail = "support@indifunded.com";

  void openWhatsApp(String number) async {
    var whatsappUrl = "whatsapp://send?phone=$number";

    try {
      bool launched = await launchUrl(Uri.parse(whatsappUrl), mode: LaunchMode.externalApplication);

      if (!launched) {
        print("Could not launch WhatsApp. Trying web link...");
        var webUrl = "https://wa.me/$number";
        await launchUrl(Uri.parse(webUrl), mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      print("Error launching WhatsApp: $e");
    }
  }




  void makeCall(String number) async {
    final Uri callUri = Uri(scheme: "tel", path: number);

    try {
      bool launched = await launchUrl(callUri, mode: LaunchMode.externalApplication);
      if (!launched) {
        print("Could not open the dialer.");
      }
    } catch (e) {
      print("Error launching phone call: $e");
    }
  }

  void sendEmail(String email) async {
    final Uri emailUri = Uri(scheme: "mailto", path: email);

    try {
      bool launched = await launchUrl(emailUri, mode: LaunchMode.externalApplication);
      if (!launched) {
        print("Could not open email client.");
      }
    } catch (e) {
      print("Error launching email: $e");
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Support"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Contact Support",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            // WhatsApp Support
            supportTile(
              title: "WhatsApp Support",
              subtitle: whatsappNumber,
              icon: Icons.watch_later_outlined,
              color: Colors.green,
              onTap: () => openWhatsApp(whatsappNumber),
            ),

            // Call Support (First Number)
            supportTile(
              title: "Call Support",
              subtitle: callSupportNumbers[0],
              icon: Icons.phone,
              color: Colors.blue,
              onTap: () => makeCall(callSupportNumbers[0]),
            ),

            // Call Support (Second Number)
            supportTile(
              title: "Call Support",
              subtitle: callSupportNumbers[1],
              icon: Icons.phone,
              color: Colors.blue,
              onTap: () => makeCall(callSupportNumbers[1]),
            ),

            // Email Support
            supportTile(
              title: "Email Support",
              subtitle: supportEmail,
              icon: Icons.email,
              color: Colors.red,
              onTap: () => sendEmail(supportEmail),
            ),
          ],
        ),
      ),
    );
  }

  Widget supportTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Icon(icon, color: color, size: 28),
        title: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 16)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 20, color: Colors.grey),
        onTap: onTap,
      ),
    );
  }
}

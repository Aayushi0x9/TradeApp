import 'package:base_code/module/bottom/profile/profile_controller.dart';
import 'package:base_code/module/bottom/profile/tradebool/trade_book_screen.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}
class _ProfileScreenState extends State<ProfileScreen> {
  final controller = Get.find<ProfileController>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.fetchPortfolioData();
      controller.loadDarkModePreference();
    });
  }
  String getInitials(String name) {
    List<String> words = name.trim().split(" ");
    if (words.length >= 2) {
      return "${words[0][0]}${words[1][0]}".toUpperCase();
    } else if (words.length == 1) {
      return words[0][0].toUpperCase();
    }
    return "";
  }
  void _showLogoutConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Confirm Logout"),
          content: const Text("Are you sure you want to log out?"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
                controller.logOutApiCall();
                // Replace this with your logout logic
              },
              child: const Text("Logout", style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         automaticallyImplyLeading: true,
        title: const Text("Profile"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child:
        Obx((){
          if (controller.holdingsData.isEmpty) {
            return const Center(child: CircularProgressIndicator()); // Show Loader until data comes
          }else{
            return  Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Gap(15),
                Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: AppColor.blue.withValues(alpha: 0.75)
                    ),
                    child:  Padding(
                      padding: const EdgeInsets.only(top: 38.0,bottom: 38,right: 20,left: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,

                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(controller.holdingsData.first.name??"",style: const TextStyle().normal14w600.textColor(AppColor.white),),
                              Text(controller.holdingsData[0].email??"",style: const TextStyle().normal14w600.textColor(AppColor.white),),
                            ],
                          ),
                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: AppColor.blue
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(28.0),
                              child: Text(      getInitials(controller.holdingsData.first.name ?? ""),
          style: const TextStyle().normal22w600.textColor(AppColor.yellowColor),),
                            ),
                          ),
                        ],
                      ),
                    )
                ),
                const Gap(20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Dark Mode", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                    Obx(() => Switch(
                      value: controller.isDarkMode.value,
                      onChanged: controller.toggleDarkMode,
                    )),
                  ],
                ),
                const Gap(15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Fund", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                    Text(
                      controller.holdingsData.first.walletBalance != null
                          ? controller.holdingsData.first.walletBalance?.toStringAsFixed(2)??""
                          : "",
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: Colors.green,
                      ),
                    )

                  ],
                ),
                const Gap(25),
                GestureDetector(
                  onTap: (){
                    Get.toNamed(AppRouter.supportScreen);
                  },
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Contact Support", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                      Icon(Icons.phone, color: Colors.blue, size: 24),
                    ],
                  ),
                ),
                const Gap(25),
                 Row(
                  children: [
                    GestureDetector(
                        onTap: (){
                          Get.to(
                                () => const TradeBookScreen(),

                          );                        },
                        child: const Text("Tradebook", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600))),
                  ],
                ),
                const Gap(15),
                GestureDetector(
                    onTap: (){

                      _showLogoutConfirmation(context);
                                          },
                    child: const Text("Logout", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600))),
              ],
            );
          }
  }
        ),
      ),
    );
  }
}

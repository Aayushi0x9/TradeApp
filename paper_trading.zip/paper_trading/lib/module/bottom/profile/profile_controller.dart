import 'package:base_code/data/model/profile_data.dart';
import 'package:base_code/data/network/api_client.dart';
import 'package:base_code/data/network/dio_client.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class ProfileController extends GetxController{
  RxBool isDarkMode = false.obs;
  RxList<Data> holdingsData = <Data>[].obs;



  Future<void> fetchPortfolioData() async {
    try {
      final response = await callApi(dio.get('https://serve.indifunded.com/api/user'),false);
      if (response?.statusCode == 200) {
        final responseData = response?.data;
        final profileData = ProfileData.fromJson(responseData);

        if (profileData.data != null) {
          holdingsData.clear();
          holdingsData.addAll(profileData.data!);
          AppPref().walletBalance = (profileData.data?.first.walletBalance ?? 0.0).toDouble(); // Casting num to double
        }
      }

    } finally{

    }
  }
  Future<void> logOutApiCall() async {
    try {
      final response = await callApi(
          dio.post(
            'https://serve.indifunded.com/api/user/logout',
          ),
          true
      );
      if (response != null && response.statusCode == 200) {
        final responseData = response.data;
        AppPref().clear();
        Get.offAllNamed(AppRouter.loginScreen);
      }  else {
        AppLoader().dismissLoader();
      }
    } on DioException {} catch (e) {
      AppLoader().dismissLoader();
    }
  }
  Future<void> loadDarkModePreference() async {
    await AppPref().isPreferenceReady;
    isDarkMode.value = AppPref().isDark ;
  }

  void toggleDarkMode(bool value) {
    isDarkMode.value = value;
    AppPref().isDarkRx.value = value;
    Get.changeThemeMode(value ? ThemeMode.dark : ThemeMode.light);
  }

}
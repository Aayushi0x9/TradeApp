import 'package:base_code/module/bottom/stock%20trading/stock_trading_controller.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';
import 'package:flutter_swipe_button/flutter_swipe_button.dart';

class StockTradingScreen extends StatefulWidget {
  const StockTradingScreen({super.key});

  @override
  StockTradingScreenState createState() => StockTradingScreenState();
}

class StockTradingScreenState extends State<StockTradingScreen> {
  final controller = Get.put<StockTradingController>(StockTradingController());
  final GlobalController globalController = Get.find<GlobalController>();
  late String title;
  late int token;
  late String orderType;
  late String instrumentType;

  @override
  void initState() {
    super.initState();
    title = Get.arguments['title'];
    token = Get.arguments['token'];
    instrumentType = Get.arguments['instrument_type'];

    controller.livePrice.value = globalController.marketPrices[token] ?? 0.0;
    orderType = Get.arguments['orderType'];
    controller.initialize(
      token,
      orderType,
      instrumentType,
      title,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteBlack(),
      appBar: AppBar(
        title: Text(title, style: TextStyle(color: AppColor.blackWhite())),
        backgroundColor: AppColor.whiteBlack(),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: AppColor.blackWhite()),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (instrumentType == "PE" || instrumentType == "CE") ...[
                    Obx(
                      () => Text(
                        controller.isLotMode.value ? "Lot" : "Quantity",
                        style: const TextStyle(fontWeight: FontWeight.bold)
                            .textColor(AppColor.blackWhite()),
                      ),
                    ),
                  ] else ...[
                    Text(
                      "Quantity",
                      style: const TextStyle(fontWeight: FontWeight.bold)
                          .textColor(AppColor.blackWhite()),
                    ),
                  ],
                  Row(
                    children: [
                      const Gap(4),
                      if (instrumentType == "PE" || instrumentType == "CE") ...[
                        Obx(() => Text(
                              controller.isLotMode.value
                                  ? "${controller.quantityText.value} Quantity" // Show actual quantity
                                  : "${(int.tryParse(controller.quantityText.value) ?? 1) ~/ controller.lotSize.value} Lot",
                              style: const TextStyle(fontWeight: FontWeight.bold)
                                  .textColor(AppColor.blackWhite()),
                            )),
                      ],
                    ],
                  ),
                ],
              ),
              const Gap(10),
              Obx(//5362
                () => TextField(
                  controller: controller.quntityController.value,
                  keyboardType: TextInputType.number,
                  onChanged: controller.onQuantityChanged,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly], // Allow only digits

                  decoration: InputDecoration(
                    border: const OutlineInputBorder(),
                    suffixIcon: (instrumentType == "PE" || instrumentType == "CE")
                        ? IconButton(
                            icon: const Icon(Icons.swap_horiz), // Toggle Button
                            onPressed: controller.toggleMode,
                          )
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text("Price",
                  style: const TextStyle(fontWeight: FontWeight.bold)
                      .textColor(AppColor.blackWhite())),
              Obx(() {
                // Get live price
                String livePrice =
                    globalController.marketPrices[token]?.toStringAsFixed(2) ??
                        "";

                // If the user is not editing, keep updating the live price
                if (controller.isEditing.value) {
                  controller.priseController.value.text = livePrice;
                }

                return TextField(
                  controller: controller.priseController.value,
                  keyboardType: TextInputType.number,
                  enabled: !controller.stopLoss.value,
                  readOnly: controller.isEditing.value,
                  // Allow editing only when enabled
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(),
                    suffixIcon: GestureDetector(
                      onTap: () {
                        // Toggle the editing state
                        controller.isEditing.value = !controller.isEditing.value;
                        controller.limit.value = false;
                        if (!controller.isEditing.value) {
                          controller.priseController.value.text = globalController.marketPrices[token]?.toStringAsFixed(2) ?? "";
                          controller.limit.value = true;
                        }
                      },
                      child: Obx(() => Icon(
                            Icons.sync_alt,
                            color: controller.isEditing.value
                                ? AppColor.blue
                                : AppColor.blackWhite(),
                          )),
                    ),
                  ),
                );
              }),
              const SizedBox(height: 20),

              if(orderType=="SELL")...[
                Obx(() {
                  return ListTile(
                    title: Text("Stoploss",
                        style: const TextStyle().textColor(AppColor.blackWhite())),
                    trailing: Switch(
                      activeColor: AppColor.blue,
                      value: controller.stopLoss.value,
                      onChanged: (value) {
                        controller.stopLoss.value = value;
                      },
                    ),
                  );
                }),
                Obx(() {
                  if (controller.stopLoss.value) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 20),
                        Text("Stoploss Price",
                            style: const TextStyle(fontWeight: FontWeight.bold)
                                .textColor(AppColor.blackWhite())),
                        TextField(
                          controller: controller.priseController.value,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            hintText: "Enter Stoploss Price",

                          ),
                        ),
                        const Gap(18)
                      ],
                    );
                  } else {
                    return const SizedBox();
                  }
                }),

              ],
              SwipeButton.expand(
                thumb: const Icon(
                  Icons.chevron_right,
                  color: AppColor.white,
                ),
                height: 60,
                activeThumbColor: AppColor.blue,
                activeTrackColor: AppColor.blue.withValues(alpha: 0.40),
                onSwipe: () async {
                  await controller.placeOrder(orderType, token);
                },
                child: Text(
                  orderType == 'BUY' ? "SWIPE TO BUY" : "SWIPE TO SELL",
                  style: const TextStyle().textColor(AppColor.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

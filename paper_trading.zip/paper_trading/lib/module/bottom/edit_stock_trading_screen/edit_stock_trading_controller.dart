import 'package:base_code/data/network/dio_client.dart';
import 'package:base_code/module/bottom/orders/order_controller.dart';
import 'package:base_code/module/bottom/profile/profile_controller.dart';
import 'package:base_code/module/home/home_controller.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class EditStockTradingController extends GetxController {
  RxBool isEditing = true.obs;
  var userEditedValue = ''.obs;
  late TabController tabController;
  RxDouble livePrice = 0.0.obs;
  RxString quantityText = '1'.obs;
  RxBool isLongTerm = true.obs;
  RxBool stopLoss = false.obs;
  RxBool limit = false.obs;
  RxBool gtt = false.obs;
  RxInt lotSize = 1.obs;
  RxString instrumentType = "".obs;
  RxString title = "".obs;
  RxString selectedExchange = "NSE".obs;
  final Rx<TextEditingController> quntityController = TextEditingController(text: '1').obs;
  void initialize(int token, String orderType, String instrument, String stockTitle) {
    instrumentType.value = instrument;
    title.value = stockTitle;
    livePrice.value = Get.find<GlobalController>().marketPrices[token] ?? 0.0;

    if (instrumentType.value == "EQ") {
      lotSize.value = 1;
    } else if (title.startsWith("NIFTY") && (title.endsWith("CE") || title.endsWith("PE"))) {
      lotSize.value = 75;
    } else if (title.startsWith("BANKNIFTY") && (title.endsWith("CE") || title.endsWith("PE"))) {
      lotSize.value = 30;
    }

    // Set quantity correctly based on lotSize

    Timer.periodic(const Duration(seconds: 1), (timer) {
      double? updatedPrice = Get.find<GlobalController>().marketPrices[token];
      if (updatedPrice != null) {
        livePrice.value = updatedPrice;
      }
    });
  }
  RxBool isLotMode = false.obs;
  void toggleMode() {
    int currentValue = int.tryParse(quntityController.value.text) ?? 0;
    // Toggle mode
    isLotMode.value = !isLotMode.value;

    if (isLotMode.value) {
      // Convert to Lot Mode
      int lotValue = (currentValue / lotSize.value).round();
      quntityController.value.text = lotValue.toString();
      quantityText.value = "$currentValue"; // Show actual quantity above
    } else {
      // Convert to Quantity Mode
      int quantityValue = currentValue * lotSize.value;
      quntityController.value.text = quantityValue.toString();
      quantityText.value = "$currentValue"; // Show actual lot above
    }
  }
  void onQuantityChanged(String text) {
    if (text.isEmpty) {
      quantityText.value = "0";
      return;
    }

    int enteredValue = int.tryParse(text) ?? 1;

    if (isLotMode.value) {
      // Lot mode: Show quantity above
      quantityText.value = "${enteredValue * lotSize.value}";
    } else {
      // Quantity mode: Show lots above
      quantityText.value = "${(enteredValue / lotSize.value).round()}";
    }
  }




  final Rx<TextEditingController> priseController = TextEditingController().obs;
  final HomeController homeController = Get.find<HomeController>();
  Future<void> placeOrder(String orderType, int token,String id) async {
    final GlobalController globalController = Get.find<GlobalController>();

    double enteredQuantity = double.tryParse(quntityController.value.text) ?? 0;
    double finalQuantity = enteredQuantity;
    String marketPrice = globalController.marketPrices[token]?.toStringAsFixed(2) ?? "";

    String title = Get.arguments['title'];

    String instrumentType = Get.arguments['instrument_type'];
    if (instrumentType == "CE" || instrumentType == "PE") {
      if (!isLotMode.value) {
        if (title.startsWith("NIFTY") && (title.endsWith("CE") || title.endsWith("PE"))) {
          finalQuantity = enteredQuantity / 75;
        } else if (title.startsWith("BANKNIFTY") && (title.endsWith("CE") || title.endsWith("PE"))) {
          finalQuantity = enteredQuantity / 30;
        }
      }
    }
    int finalQuantityInt = finalQuantity.toInt(); // Convert to int before sending

    if (instrumentType == "CE" || instrumentType == "PE") {
      if (title.startsWith("NIFTY") && (title.endsWith("CE") || title.endsWith("PE"))) {
        if(isLotMode.value==false){
          if (enteredQuantity % 75 != 0) {
            Get.snackbar("Error", "Enter a proper quantity for NIFTY. Allowed values: 75, 150, 225, etc.",
                snackPosition: SnackPosition.TOP);
            return;
          }
        }

      } else if (title.startsWith("BANKNIFTY") && (title.endsWith("CE") || title.endsWith("PE")) ) {
        if(isLotMode.value==false) {

          if (enteredQuantity % 30 != 0) {
            Get.snackbar("Error", "Enter a proper quantity for BANKNIFTY. Allowed values: 30, 60, 90, etc.",
                snackPosition: SnackPosition.TOP);
            return;
          }
        }

      }
    }


    final url =  "https://serve.indifunded.com/api/order/modify/$id";
    Map<String, dynamic> payload = {
      "price":isEditing.value? priseController.value.text:marketPrice,
      "quantity": finalQuantityInt,
    };

    try {
      final response = await dio.post(url, data: payload);
      if (response.statusCode == 200) {
        Get.back();
        ProfileController controller;
        if (Get.isRegistered<ProfileController>()) {
          controller = Get.find<ProfileController>();
        } else {
          controller = Get.put(ProfileController());
        }
        controller.fetchPortfolioData();
        final orderController = Get.find<OrderController>();
        orderController.fetchPortfolioData("open");
        orderController.fetchPortfolioData("executed");
        Get.snackbar("Success", "Order placed successfully",
            snackPosition: SnackPosition.TOP);
      }
    } on DioException catch (error) {
      if (error.response?.statusCode == 400) {
        String errorMessage = error.response?.data["message"] ??
            "Order placement failed";
        Get.snackbar("Error", errorMessage, snackPosition: SnackPosition.TOP);
      } else {
        Get.snackbar("Error", "Order placement failed",
            snackPosition: SnackPosition.TOP);
      }
    }
  }
}


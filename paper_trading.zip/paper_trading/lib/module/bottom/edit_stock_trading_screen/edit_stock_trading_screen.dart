import 'package:base_code/module/bottom/edit_stock_trading_screen/edit_stock_trading_controller.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';
import 'package:flutter_swipe_button/flutter_swipe_button.dart';

class EditStockTradingScreen extends StatefulWidget {
  const EditStockTradingScreen({super.key});
  @override
  State<EditStockTradingScreen> createState() => EditStockTradingScreenState();
}
class EditStockTradingScreenState extends State<EditStockTradingScreen> {
  final controller = Get.put<EditStockTradingController>(EditStockTradingController());
  final GlobalController globalController = Get.find<GlobalController>();
  late String title;
  late int token;
  late String orderType;
  late String id;
  late String instrumentType;
  static  int quantity = 0;
  static  double price = 0.0;
  @override
  void initState() {
    super.initState();
    title = Get.arguments['title'];
    token = Get.arguments['token'];
    instrumentType = Get.arguments['instrument_type'];
    id = Get.arguments['id'];
    orderType = Get.arguments['orderType'];
    int inputQuantity = Get.arguments['quantity'];
    price = Get.arguments['price'];

    // Initialize the controller first
    controller.initialize(token, orderType, instrumentType, title);

    // Ensure lotSize is set before using it
      if (instrumentType == "CE" || instrumentType == "PE") {
        quantity = inputQuantity * controller.lotSize.value; // Convert lot to quantity
      } else {
        quantity = inputQuantity;
      }
      controller.isLotMode.value = false;  // Start with quantity mode

      controller.quntityController.value.text = quantity.toString();
      controller.quantityText.value = inputQuantity.toString();
    controller.priseController.value.text = price.toString();

    controller.livePrice.value = globalController.marketPrices[token] ?? 0.0;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.whiteBlack(),
      appBar: AppBar(
        title: Text(title, style: TextStyle(color: AppColor.blackWhite())),
        backgroundColor: AppColor.whiteBlack(),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: AppColor.blackWhite()),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body:  Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if(instrumentType == "PE" || instrumentType == "CE")...[
                  Obx(
          ()=> Text(
                      controller.isLotMode.value ? "Lot" : "Quantity",
                      style: const TextStyle(fontWeight: FontWeight.bold)
                          .textColor(AppColor.blackWhite()),
                    ),
                  ),
                ]else...[
                  Text(
                    "Quantity",
                    style: const TextStyle(fontWeight: FontWeight.bold)
                        .textColor(AppColor.blackWhite()),
                  ),
                ],
                Row(
                  children: [

                    const Gap(4),
                    Obx(() => Text(
                      controller.isLotMode.value
                          ? "${controller.quantityText.value} Quantity"
                          : "${controller.quantityText.value} Lot",
                      style: const TextStyle(fontWeight: FontWeight.bold).textColor(AppColor.blackWhite()),
                    )),

                  ],
                ),
              ],
            ),
            const Gap(10),
            Obx(()
            => TextField(
                controller: controller.quntityController.value,
                keyboardType: TextInputType.number,
                onChanged: controller.onQuantityChanged,
                decoration: InputDecoration(
                  border: const OutlineInputBorder(),
                  suffixIcon: (instrumentType == "PE" || instrumentType == "CE")
                      ? IconButton(

                    icon: const Icon(Icons.swap_horiz), // Toggle Button
                    onPressed: controller.toggleMode,
                  )
                      : null,
                ),
              ),
            ),

            const SizedBox(height: 20),
            Text("Price", style: const TextStyle(fontWeight: FontWeight.bold).textColor(
                AppColor.blackWhite())),
            Obx(() {
              String marketPrice =
                  globalController.marketPrices[token]?.toStringAsFixed(2) ?? '0.00';
              return TextField(
                controller: controller.priseController.value,
                keyboardType: TextInputType.number,
                readOnly: !controller.isEditing.value, // Allow editing only if isEditing is true
                onChanged: (text) {
                  controller.priseController.value.text = text;
                },
                decoration: InputDecoration(
                  border: const OutlineInputBorder(),
                  suffixIcon: GestureDetector(
                    onTap: () {
                      controller.isEditing.value = !controller.isEditing.value;
                      if (!controller.isEditing.value) {
                        // When not editing, display market price
                        controller.priseController.value.text = marketPrice;
                      } else {
                        // When editing, set the user-input price
                        controller.priseController.value.text = Get.arguments['price'].toString();
                      }
                    },
                    child: Icon(
                      Icons.sync_alt,
                      color: controller.isEditing.value ? AppColor.blue : AppColor.blackWhite(),
                    ),
                  ),
                ),
              );
            }),

            const SizedBox(height: 20),
            SwipeButton.expand(
              thumb: const Icon(
                Icons.chevron_right,
                color: AppColor.white,
              ),
              height: 60,
              activeThumbColor: AppColor.blue,
              activeTrackColor: AppColor.blue.withValues(alpha: 0.50),
              onSwipe: () async {
                await controller.placeOrder(orderType,token,id);
              },
              child: Text(
                "Modify",
                style: const TextStyle().textColor(AppColor.white),
              ),
            ),
          ],
        ),
      ),
    );
  }

}

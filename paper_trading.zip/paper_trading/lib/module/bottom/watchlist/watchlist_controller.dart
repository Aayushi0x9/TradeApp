import 'package:base_code/data/model/watch_list_modal.dart';
import 'package:base_code/data/network/api_client.dart';
import 'package:base_code/data/network/dio_client.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class WatchListController extends GetxController {
  RxList<WatchListModalData> watchlist1 = <WatchListModalData>[].obs;
  RxList<WatchListModalData> watchlist2 = <WatchListModalData>[].obs;
  RxList<WatchListModalData> watchlist3 = <WatchListModalData>[].obs;
  TextEditingController searchController = TextEditingController();
  RxString searchString = ''.obs;
  Future<void> fetchAllWatchlists() async {
   await fetchWatchlistData("Watchlist 1", watchlist1);
    fetchWatchlistData("Watchlist 2", watchlist2);
    fetchWatchlistData("Watchlist 3", watchlist3);
  }

  Future<void> fetchWatchlistData(String watchlistName, RxList<WatchListModalData> watchlist) async {
    try {
      final response = await callApi(dio.get("https://serve.indifunded.com/api/wishlist/$watchlistName"),false);
      if (response != null && response.statusCode == 200) {
        if (response.data != null) {
          WatchListData watchListData = WatchListData.fromJson(response.data);
          if (watchListData.data != null) {
            watchlist.clear();
            watchlist.addAll(watchListData.data!);
            watchlist.refresh();
            update();
            List<int> tokens = watchlist.map((e) => e.instrumentToken ?? 0).where((token) => token != 0).toList();
            final GlobalController globalController = Get.find<GlobalController>();
            print("====>");
            print(tokens);
            await _waitForWebSocketConnection(globalController);
            globalController.subscribeToTokens(tokens);
          }
        }
      }
    } finally{

    }
  }
  Future<void> _waitForWebSocketConnection(GlobalController globalController) async {
    const maxAttempts = 10;
    int attempts = 0;

    while (!globalController.isConnected && attempts < maxAttempts) {
      print("Waiting for WebSocket connection... Attempt ${attempts + 1}");
      await Future.delayed(const Duration(milliseconds: 500));
      attempts++;
    }

    if (!globalController.isConnected) {
      print("WebSocket connection failed after $maxAttempts attempts.");
    } else {
      print("WebSocket connection established.");
    }
  }
}

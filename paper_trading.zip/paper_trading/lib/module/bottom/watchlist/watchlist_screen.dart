import 'package:base_code/data/model/search_data.dart';
import 'package:base_code/data/model/watch_list_modal.dart';
import 'package:base_code/data/network/api_client.dart';
import 'package:base_code/data/network/dio_client.dart';
import 'package:base_code/module/bottom/profile/profile_controller.dart';
import 'package:base_code/module/bottom/stock%20trading/stock_trading_screen.dart';
import 'package:base_code/module/bottom/watchlist/watchlist_controller.dart';
import 'package:base_code/module/home/home_controller.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class WatchlistPage extends StatefulWidget {
  const WatchlistPage({super.key});
  @override
  State<WatchlistPage> createState() => _WatchlistPageState();
}
class _WatchlistPageState extends State<WatchlistPage> {
  final controller = Get.find<WatchListController>();
  final GlobalController globalController = Get.find<GlobalController>();
  final HomeController homeController = Get.put(HomeController());
  final profileController = Get.find<ProfileController>();


  bool isOverviewOpen = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.fetchAllWatchlists();
    });
  }
  Future<void> _onRefresh() async {
    // Logic to refresh data, for example:
   await controller.fetchAllWatchlists();
   await homeController.fetchInstrumentTokens();
   await profileController.fetchPortfolioData();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          title: Obx(
             ()=> Text(
              "Watchlist",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color:AppPref().isDarkRx.value == true ? AppColor.greenColor : AppColor.blue ,
                  fontSize: 20),
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 12.0),
              child: GestureDetector(
                  onTap: (){
                    setState(() {
                      isOverviewOpen = !isOverviewOpen;
                    });
                  },
                  child: Icon(isOverviewOpen ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,size: 30,)),
            )


          ],
          bottom: PreferredSize(
            preferredSize: Size.fromHeight(isOverviewOpen ? 120 : 48),
            child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (isOverviewOpen)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 0, vertical: 8),
                    height: 70,
                    child: Obx(
                      () => ListView.builder(
                          shrinkWrap: true,
                          scrollDirection: Axis.horizontal,
                          padding:  EdgeInsets.zero,
                          itemCount:
                          homeController.instrumentTokens.keys.length,
                          itemBuilder: (context, index) {
                            String title = homeController.instrumentTokens.keys.elementAt(index);
                            int? token =
                                homeController.instrumentTokens[title];
                            return Obx(() {
                              double? livePrice = Get.find<GlobalController>().marketPrices[token];
                              double? baseline = Get.find<GlobalController>().marketClosePrices[token];
                              String displayValue = livePrice != null ? livePrice.toStringAsFixed(2) : "Fetching...";
                                String changeText = "";
                                if (livePrice != null && baseline != null && baseline > 0) {
                                  double diff = livePrice - baseline;
                                  double perc = (diff / baseline) * 100;
                                  changeText = "${diff >= 0 ? '+' : ''}${diff.toStringAsFixed(2)} (${perc >= 0 ? '+' : ''}${perc.toStringAsFixed(2)}%)";
                                }
                                return Padding(
                                  padding: const EdgeInsets.only(right: 12.0,left: 12),
                                  child: OverviewCard(
                                    title: title,
                                    value: displayValue,
                                    change: changeText,
                                  ),
                                );
                              },
                            );
                          }),
                    ),
                  ),
                Obx(
                    ()=> TabBar(
                    tabs:  const [
                      Tab(text: "Watchlist 1"),
                      Tab(text: "Watchlist 2"),
                      Tab(text: "Watchlist 3"),
                    ],
                    labelColor: AppPref().isDarkRx.value == true ? AppColor.greenColor : AppColor.blue,
                    unselectedLabelColor: AppPref().isDarkRx.value == true ? AppColor.white : AppColor.black,
                    labelStyle: const TextStyle(fontWeight: FontWeight.bold).normal14w600,
                    indicatorColor: AppPref().isDarkRx.value == true ? AppColor.greenColor : AppColor.blue,
                  ),
                ),
              ],
            ),

          ),
        ),
        body: Column(
          children: [
            //_buildSearchBar(),
            const Gap(15),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: Obx(
                    () => CommonTextField(
                  controller: homeController.textEditingController.value,
                  prefixIcon: Icon(Icons.search, color: AppColor.blackWhite()),
                  // Only show the suffix icon if the search query is not empty
                  suffixIcon: homeController.searchQuery.value.isNotEmpty
                      ? GestureDetector(
                    onTap: () {
                      homeController.textEditingController.value.clear();
                      homeController.searchQuery.value = "";
                      // Optionally, unfocus the field if needed:
                      FocusManager.instance.primaryFocus?.unfocus();
                    },
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8.0),
                      child: Icon(Icons.close),
                    ),
                  )
                      : null,
                  hintText: "Search & add",
                  onChange: (value) {
                    homeController.searchQuery.value = value??"";
                  },
                ),
              ),
            ),

            Obx(() {
              if (homeController.searchQuery.value.isEmpty) {
                return Expanded(
                  child: TabBarView(
                    children: [
                      RefreshIndicator(
                        onRefresh: _onRefresh,
                        child: _buildTabView(controller.watchlist1),
                      ),
                      RefreshIndicator(
                        onRefresh: _onRefresh,
                        child: _buildTabView(controller.watchlist2),
                      ),
                      RefreshIndicator(
                        onRefresh: _onRefresh,
                        child: _buildTabView(controller.watchlist3),
                      ),
                    ],
                  ),
                );

              }
              return Expanded(
                flex: 1,
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: homeController.searchResults.length,
                  itemBuilder: (context, index) {
                    SearchAllData data = homeController.searchResults[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      child: InkWell(
                        onTap: (){
                          Get.back();
                        },
                        child: ListTile(
                          leading: Container(
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(8),
                            ),
                            padding: const EdgeInsets.all(8),
                            child: Text(data.exchange ?? ''),
                          ),
                          title: Text(data.name ?? ''),
                          trailing: GestureDetector(
                              onTap: () async {
                                //_showWishlistDialog(data.instrumentToken);
                                FocusScope.of(context).unfocus();

                                int currentTabIndex = (DefaultTabController.of(context).index ) + 1;

                                await homeController.addToWishlist("Watchlist $currentTabIndex", data.instrumentToken);
                                controller.fetchAllWatchlists();
                                homeController.textEditingController.value.clear();
                                homeController.searchQuery.value = ""; // Also clear the search query
                              },
                              child: const Icon(Icons.add)),

                        ),
                      ),
                    );
                  },
                ),
              );
            }
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
  Obx _buildTabView(RxList<WatchListModalData> watchlist) {
    return Obx(() {
      String query = controller.searchString.value.trim().toLowerCase();
      List<WatchListModalData> filteredList = query.isEmpty
          ? watchlist
          : watchlist.where((stock) {
        final nameMatch = stock.name?.toLowerCase().contains(query) ?? false;
        final symbolMatch = stock.tradingsymbol?.toLowerCase().contains(query) ?? false;
        return nameMatch || symbolMatch;
      }).toList();
      if (filteredList.isEmpty) {
        return const Center(child: Text("No Data Found"));
      }
      return ListView.separated(
        itemCount: filteredList.length,
        padding: const EdgeInsets.only(top: 12,right: 12,left: 12),
        separatorBuilder: (context, index) => const Divider(),
        itemBuilder: (context, index) {
          var stock = filteredList[index];

          return GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: () {
              Get.back();
              showStockBottomSheet(context, stock);
            },
            onLongPress: () {
              Get.defaultDialog(
                title: "Delete",
                middleText: "Do you want to delete this stock from the watchlist?",
                textConfirm: "Delete",
                textCancel: "Cancel",
                confirmTextColor: Colors.white,
                onConfirm: () async {
                  final response = await callApi(
                    dio.delete("https://serve.indifunded.com/api/wishlist/${stock.sId}"),
                    false
                  );
                  if (response != null && response.statusCode == 200) {
                    controller.watchlist1.removeWhere((item) => item.sId == stock.sId);
                    controller.watchlist2.removeWhere((item) => item.sId == stock.sId);
                    controller.watchlist3.removeWhere((item) => item.sId == stock.sId);
                    Get.back(); // Colse the dialog
                  } else {
                    Get.back();
                  }
                },
              );
            },
            child: Obx(() {
              final lastTradedPrice = globalController.marketPrices[stock.instrumentToken ?? 0] ?? 0.0;
              final closePrice = globalController.marketClosePrices[stock.instrumentToken ?? 0] ?? 0.0;
              final priceDifference = lastTradedPrice - closePrice;
              final percentageChange = closePrice == 0.0 ? 0.0 : (priceDifference / closePrice) * 100;
              final isPositive = priceDifference >= 0;

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(stock.name ?? "", style: const TextStyle(letterSpacing: 0).normal15w500),
                      Text("$lastTradedPrice", style: const TextStyle().normal15w500),
                    ],
                  ),
                  const Gap(4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(stock.exchange ?? "", style: const TextStyle().normal11w500),
                      Text(
                        "${isPositive ? '+' : ''}${priceDifference.toStringAsFixed(2)} (${isPositive ? '+' : ''}${percentageChange.toStringAsFixed(2)}%)",
                        style: TextStyle(
                          color: isPositive ? Colors.green : Colors.red,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],//
                  ),
                ],
              );
            }),

          );
        },
      );
    });
  }
  void showStockBottomSheet(BuildContext context, WatchListModalData  stock) {
    int token = stock.instrumentToken!;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return Obx(() {
          double? livePrice = Get.find<GlobalController>().marketPrices[token];
          double? baseline = Get.find<GlobalController>().marketClosePrices[token];
          String displayValue = livePrice != null ? livePrice.toStringAsFixed(2) : "Fetching...";
          String changeText = "";
          Color changeColor = Colors.black;
          if (livePrice != null && baseline != null && baseline > 0) {
            double diff = livePrice - baseline;
            double perc = (diff / baseline) * 100;
            changeText =
            "${diff >= 0 ? '+' : ''}${diff.toStringAsFixed(2)} (${perc >= 0 ? '+' : ''}${perc.toStringAsFixed(2)}%)";
            changeColor = diff >= 0 ? Colors.green : Colors.red;
          }
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Stock Name
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    stock.name ?? '',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 4),
                // Stock Price & Change
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    RichText(
                      text: TextSpan(
                        style: const TextStyle(fontSize: 16, color: Colors.black),
                        children: [
                          TextSpan(
                            text: "$displayValue ",
                            style: TextStyle(
                                fontWeight: FontWeight.bold, color: changeColor),
                          ),
                          TextSpan(
                            text: changeText,
                            style: TextStyle(color: changeColor),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Buy & Sell Buttons
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Get.to(() => const StockTradingScreen(),
                            arguments: {
                              'title': stock.name ?? '',
                              'livePrice': livePrice ?? 0.0,
                              'token': token,
                              'orderType': 'BUY',
                              'instrument_type': stock.instrumentType,
                            },
                          );
                          Navigator.pop(context);

                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("BUY",
                            style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Get.to(
                                () => const StockTradingScreen(),
                            arguments: {
                              'title': stock.name ?? '',
                              'livePrice': livePrice ?? 0.0,
                              'token': token,
                              'orderType': 'SELL', // Pass SELL Type
                              'instrument_type': stock.instrumentType,

                            },
                          );
                          Navigator.pop(context);

                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("SELL",
                            style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: () {
                    Get.toNamed(AppRouter.chartScreen, arguments: {
                      'token': token,
                    });
                    },
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.bar_chart, color: Colors.blue),
                      SizedBox(width: 5),
                      Text("View chart", style: TextStyle(color: Colors.blue, fontSize: 16)),
                      SizedBox(width: 5),
                      Icon(Icons.arrow_forward, color: Colors.blue),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          );
        });
      },
    );
  }
}
class OverviewCard extends StatelessWidget {
  final String title;
  final String value;
  final String change;

  const OverviewCard({
    super.key,
    required this.title,
    required this.value,
    required this.change,
  });
  @override
  Widget build(BuildContext context) {
    Color changeColor = change.startsWith('+') ? Colors.green : Colors.red;
    return Column(
crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 14,
              fontWeight: FontWeight.w500

          ),
        ),
        const Gap(4),
        Row(
          children: [
            Text(
              value,
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w500
              ),
            ),
            const Gap(4),

            Text(
              change,
              style: TextStyle(
                fontSize: 13,
                color: changeColor,
                  fontWeight: FontWeight.w500

              ),
            ),
          ],
        ),

      ],
    );
  }
}

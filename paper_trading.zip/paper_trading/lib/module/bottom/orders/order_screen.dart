import 'package:base_code/data/model/executed.dart';
import 'package:base_code/data/model/order.dart';
import 'package:base_code/data/network/api_client.dart';
import 'package:base_code/data/network/dio_client.dart';
import 'package:base_code/module/bottom/edit_stock_trading_screen/edit_stock_trading_screen.dart';

import 'package:base_code/module/bottom/orders/order_controller.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';


class OrderScreen extends StatefulWidget {
  const OrderScreen({super.key});

  @override
  State<OrderScreen> createState() => _OrderScreenState();
}

class _OrderScreenState extends State<OrderScreen> {
  final controller = Get.find<OrderController>();
  final GlobalController globalController = Get.find<GlobalController>();
  Future<void> _onRefresh() async {
    // Logic to refresh data, for example:
    await controller.fetchPortfolioData("open");
    await controller.fetchPortfolioData("executed");

  }
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          title: Obx(
            ()=> Text(
              "Order",
              style: TextStyle(
                  fontWeight: FontWeight.bold, color:AppPref().isDarkRx.value == true ? AppColor.greenColor : AppColor.blue , fontSize: 20),
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(48.0),

            child: Obx(
                ()=> TabBar(
                labelColor: AppPref().isDarkRx.value == true ? AppColor.greenColor : AppColor.blue,
                unselectedLabelColor: AppPref().isDarkRx.value == true ? AppColor.white : AppColor.black,
                labelStyle: const TextStyle(fontWeight: FontWeight.bold).normal14w600,
                indicatorColor: AppPref().isDarkRx.value == true ? AppColor.greenColor : AppColor.blue,
                tabs: const [
                  Tab(text: "Open"),
                  Tab(text: "Executed"),
                ],
              ),
            ),
          ),
        ),
        body: TabBarView(
          children: [
            RefreshIndicator(
                onRefresh:_onRefresh,

            child: Obx(() => _buildListView(controller.orderDataList))),
            RefreshIndicator(
                onRefresh:_onRefresh,

                child: Obx(() => _buildExecutedListView(controller.executedData))),
          ],
        ),
      ),
    );
  }

  Widget _buildListView(List<OrderData> data) {
    return data.isEmpty
        ? const Center(child: Text("No Data Found"))
        : ListView.builder(
      itemCount: data.length,
      itemBuilder: (context, index) {
        final stock = data[index];
        return Column(
          children: stock.data!.asMap().entries.map((entry) => _buildStockItem(entry.value, index)).toList(),
        );
      },
    );
  }
  Widget _buildStockItem(OrderDetails stock,index) {


    String formatTime(String? timestamp) {
      if (timestamp == null || timestamp.isEmpty) return "";

      DateTime dateTime = DateTime.parse(timestamp).toLocal();
      return DateFormat('HH:mm:ss').format(dateTime);
    }
    return GestureDetector(
        behavior: HitTestBehavior.translucent,

        onTap: (){

          showStockBottomSheet(context, stock, index);

        },
         child: Padding(
          padding: const EdgeInsets.only(left: 12,right: 12,bottom: 12),
          child: SizedBox(
            width: double.infinity,

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Gap(12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          color: (stock.buyType ?? "").toUpperCase() == "BUY"
                              ? Colors.blue.withValues(alpha: 0.3)
                              : Colors.red.withValues(alpha: 0.3), // Use withOpacity instead of withValues
                          child: Padding(
                            padding: const EdgeInsets.only(right: 6.0, left: 6),
                            child: Text(
                              (stock.buyType ?? "").toUpperCase(),
                              style: const TextStyle().textColor((stock.buyType ?? "").toUpperCase() == "BUY"?Colors.blue:AppColor.redColor),
                            ),
                          ),
                        ),
                        const Gap(5),
                        Text(stock.quantity.toString()),
                        const Gap(5),
                        Text(
                          stock.instrumentType == "EQ" ? "Qty" : "Lot",


                        ),
                      ],
                    ),
                    Row(
                      children: [
                        const Icon(Icons.watch_later_outlined,size: 15,),
                        const Gap(3),
                        Text(formatTime(stock.createdAt)),
                        const Gap(5),
                        Container(
                          color: Colors.green.withValues(alpha: 0.3),
                          child: Padding(
                            padding: const EdgeInsets.only(right: 6.0, left: 6),
                            child: Text(
                              (stock.status ?? "").toUpperCase() == "EXECUTED" ? "COMPLETE" : (stock.status ?? "").toUpperCase(),
                              style: const TextStyle().textColor(AppColor.greenColor),
                            ),
                          ),
                        ),

                      ],
                    )
                  ],
                ),
                const Gap(5),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(stock.name ?? "N/A"),
                    Text(stock.price?.toStringAsFixed(2)??"" ),
                  ],
                ),
                const Gap(5),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,

                  children: [
                    Text(
                      "${stock.exchange}  ${stock.showType?.toUpperCase() ?? "N/A"}",
                    ),
                    Obx(() {
                      final lastTradedPrice =
                          globalController.marketPrices[stock.instrumentId ?? 0] ?? 0.0;
                      return Text("LTP ${lastTradedPrice.toString()}",
                          style: const TextStyle());
                    }),

                  ],
                ),

                const Divider()
              ],
            ),
          ),
        )

    );
  }
  void showStockBottomSheet(BuildContext context, OrderDetails stock,index) {
    int token = stock.instrumentId??0;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return Obx(() {
          double? livePrice = Get.find<GlobalController>().marketPrices[token];
          double? baseline = Get.find<GlobalController>().marketClosePrices[token];
          String displayValue = livePrice != null ? livePrice.toStringAsFixed(2) : "Fetching...";
          String changeText = "";
          Color changeColor = Colors.black;
          if (livePrice != null && baseline != null && baseline > 0) {
            double diff = livePrice - baseline;
            double perc = (diff / baseline) * 100;
            changeText =
            "${diff >= 0 ? '+' : ''}${diff.toStringAsFixed(2)} (${perc >= 0 ? '+' : ''}${perc.toStringAsFixed(2)}%)";
            changeColor = diff >= 0 ? Colors.green : Colors.red;
          }
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Stock Name
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    stock.name ?? '',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 4),
                // Stock Price & Change
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    RichText(
                      text: TextSpan(
                        style: const TextStyle(fontSize: 16, color: Colors.black),
                        children: [
                          TextSpan(
                            text: "$displayValue ",
                            style: TextStyle(
                                fontWeight: FontWeight.bold, color: changeColor),
                          ),
                          TextSpan(
                            text: changeText,
                            style: TextStyle(color: changeColor),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Get.to(() => const EditStockTradingScreen(),
                            arguments: {
                              'title': stock.name ?? '',
                              'livePrice': stock.price,
                              'token': stock.instrumentId,
                              'id': stock.id,
                              'orderType': 'BUY',
                              'quantity': stock.quantity,
                              'price': stock.price?.toDouble(),
                              'instrument_type': stock.instrumentType,
                            },
                          );
                          Navigator.pop(context);

                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("Modify",
                            style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Get.defaultDialog(
                            title: "Cancel Order",
                            middleText: "Are you sure you want to cancel your order?",
                            textCancel: "No",
                            textConfirm: "Yes",
                            confirmTextColor: Colors.white,
                            onConfirm: () async {
                              final response = await callApi(dio.post(
                                  "https://serve.indifunded.com/api/order/cancel/${stock.id}"));

                              if (response?.statusCode == 200) {
                                controller.orderDataList.removeWhere((order) =>
                                order.data != null && order.data!.any((item) => item.id == stock.id));
                                controller.update(); // Refresh UI
                                controller.orderDataList.refresh();
                                controller.fetchPortfolioData("open");
                                Get.back(); // Close the dialog
AppToast().showAppToast( "Order canceled successfully");
                              } else {
                                AppToast().showAppToast( "Failed to cancel the order");
                              }
                            },

                          );
                          Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("Cancel",
                            style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: () {
                    Get.toNamed(AppRouter.chartScreen, arguments: {
                      'token': token,
                    });
                  },
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.bar_chart, color: Colors.blue),
                      SizedBox(width: 5),
                      Text("View chart", style: TextStyle(color: Colors.blue, fontSize: 16)),
                      SizedBox(width: 5),
                      Icon(Icons.arrow_forward, color: Colors.blue),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          );
        });
      },
    );
  }

  Widget _buildExecutedListView(List<ExecutedData> executedOrders) {
    return executedOrders.isEmpty
        ? const Center(child: Text("No Executed Orders Found"))
        : ListView.builder(
      itemCount: executedOrders.length,
      itemBuilder: (context, index) {
        final order = executedOrders[index];

        if (order.data == null || order.data!.isEmpty) {
          return const SizedBox(); // Return an empty widget if no data
        }

        return Column(
          children: order.data!
              .map((executedOrder) => _buildExecutedOrderItem(executedOrder))
              .toList(),
        );
      },
    );
  }



  Widget _buildExecutedOrderItem(ExecutedAllData order) {
    String formatTime(String? timestamp) {
      if (timestamp == null || timestamp.isEmpty) return "";

      DateTime dateTime = DateTime.parse(timestamp).toLocal(); // Convert to local time
      return DateFormat('HH:mm:ss').format(dateTime); // Format as HH:mm:ss
    }
    return  Padding(
      padding: const EdgeInsets.only(left: 12,right: 12,bottom: 12),
      child: SizedBox(
        width: double.infinity,

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Gap(12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      color: (order.buyType ?? "").toUpperCase() == "BUY"
                          ? Colors.blue.withValues(alpha: 0.3)
                          : Colors.red.withValues(alpha: 0.3), // Use withOpacity instead of withValues
                      child: Padding(
                        padding: const EdgeInsets.only(right: 6.0, left: 6),
                        child: Text(
                          (order.buyType ?? "").toUpperCase(),
                          style: const TextStyle().textColor((order.buyType ?? "").toUpperCase() == "BUY"?Colors.blue:AppColor.redColor),
                        ),
                      ),
                    ),

                    const Gap(5),
                    Text(order.quantity.toString()),
                    const Gap(5),
                    Text(
                      order.instrumentType == "EQ" ? "Qty" : "Lot",


                    ),

                  ],
                ),
                Row(
                  children: [
                   const Icon(Icons.watch_later_outlined,size: 15,),
                   const Gap(3),
                    Text(formatTime(order.createdAt)),
                    const Gap(5),
                    Container(
                      color: Colors.green.withValues(alpha: 0.3), // Use withOpacity instead of withValues
                      child: Padding(
                        padding: const EdgeInsets.only(right: 6.0, left: 6),
                        child: Text(
                          (order.status ?? "").toUpperCase() == "EXECUTED" ? "COMPLETE" : (order.status ?? "").toUpperCase(),
                          style: const TextStyle().textColor(AppColor.greenColor),
                        ),
                      ),
                    ),

                  ],
                )
              ],
            ),
            const Gap(5),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(order.name ?? "N/A"),
                Text(order.price?.toStringAsFixed(2)??"" ),
              ],
            ),
            const Gap(5),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,

              children: [
                Text(order.exchange ?? "N/A"),
                 Text( order.showType?.toUpperCase()??"",style: const TextStyle(),),
              ],
            ),
            
            const Divider()
          ],
        ),
      ),
    );


    //   ListTile(
    //
    //
    //   title: Text(order.tradingsymbol ?? "N/A"),
    //   subtitle: Text(order.exchange ?? "N/A"),
    //   trailing: Column(
    //     crossAxisAlignment: CrossAxisAlignment.end,
    //     children: [
    //       Text("Avg: ${order.avgPrice}"),
    //       Text(
    //         "${order.quantity} ",
    //
    //       ),
    //     ],
    //   ),
    // );
  }


}

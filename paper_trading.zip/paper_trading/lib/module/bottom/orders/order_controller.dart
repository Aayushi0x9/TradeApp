import 'package:base_code/data/model/executed.dart';
import 'package:base_code/data/model/order.dart';
import 'package:base_code/data/network/api_client.dart';
import 'package:base_code/data/network/dio_client.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class OrderController extends GetxController{
  final GlobalController globalController = Get.find<GlobalController>();
  RxList<OrderData> orderDataList = <OrderData>[].obs;
  RxList<ExecutedData> executedData = <ExecutedData>[].obs;
  Future<void> fetchPortfolioData(String type) async {
    try {
      final response = await callApi(dio.get('https://serve.indifunded.com/api/portfolio?type=$type'),false);
      if (response?.statusCode == 200) {
        if (type == "open") {
          OrderData watchListData = OrderData.fromJson(response?.data);



orderDataList.clear();
            orderDataList.add(watchListData);
           // globalController.subscribeToTokens(newTokens);

        } else if (type == "executed") {
          ExecutedData executedDataModal = ExecutedData.fromJson(response?.data);





            executedData.clear();
            executedData.add(executedDataModal);
            executedData.refresh();
          //  globalController.subscribeToTokens(newTokens);

        }
      }
    } finally {
      // Handle any cleanup if needed
    }
  }


  double calculatePercentage(int instrumentId) {
    double lastTradedPrice = globalController.marketPrices[instrumentId] ?? 0.0;
    double closePrice = globalController.marketClosePrices[instrumentId] ?? 0.0;
    if (closePrice == 0.0) return 0.0;
    return ((lastTradedPrice - closePrice) / closePrice) * 100;
  }
  double calculateDifference(int instrumentId) {
    double lastTradedPrice = globalController.marketPrices[instrumentId] ?? 0.0;
    double closePrice = globalController.marketClosePrices[instrumentId] ?? 0.0;

    return lastTradedPrice - closePrice;
  }
  @override
  void onInit() {
    super.onInit();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      fetchPortfolioData("open");
      fetchPortfolioData("executed");
    });

  }

}
import 'package:base_code/module/bottom/bottom_controller.dart';
import 'package:base_code/module/bottom/orders/order_controller.dart';
import 'package:base_code/module/bottom/orders/order_screen.dart';
import 'package:base_code/module/bottom/portfolio/portfolio_controller.dart';
import 'package:base_code/module/bottom/portfolio/portfolio_screen.dart';
import 'package:base_code/module/bottom/profile/profile_controller.dart';
import 'package:base_code/module/bottom/profile/profile_screen.dart';
import 'package:base_code/module/bottom/watchlist/watchlist_controller.dart';
import 'package:base_code/module/bottom/watchlist/watchlist_screen.dart';
import 'package:base_code/package/screen_packages.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';

class BottomBarScreen extends StatelessWidget {
  final BottomBarController bottomBarController = Get.put(BottomBarController());
  final WatchListController watchListController = Get.put(WatchListController());
  final ProfileController controller = Get.put(ProfileController());
  final ordersController = Get.put<OrderController>(OrderController());
  final portController = Get.put<PortfolioController>(PortfolioController());


  BottomBarScreen({super.key});

  final PersistentTabController _controller = PersistentTabController(initialIndex: 0);

  List<Widget> _buildScreens() {
    return [
    //  const HomeScreen(),
      const WatchlistPage(),
      const OrderScreen(),
      const PortfolioScreen(),
      const ProfileScreen(),
    ];
  }
  void callApiOnIndexChange(int index) {
    if (index == 0) {
      // Call Watchlist API
     // watchListController.fetchAllWatchlists();
    }
    if (index == 1) {
      // OrdersController.fetchPortfolioData("open");
      // OrdersController.fetchPortfolioData("executed");

    }
    if (index == 2) {

    //  portController.fetchPortfolioData("position");

    }if(index==3){
     // controller.fetchPortfolioData();
    }
  }
  List<PersistentBottomNavBarItem> _navBarsItems() {
    return List.generate(4, (index) {
      String title;
      Widget  iconWidget;

      switch (index) {

        case 0:
          title = "watchlist";
          iconWidget =const Icon(Icons.bookmark_border, size: 24);
          break;
        case 1:
          title = "Orders";

          iconWidget = Image.asset(AppImage.lists,height: 20,);
          break;
        case 2:
          title = "Portfolio";
          iconWidget = Image.asset(AppImage.briefcase,height: 20,);
          break;
        case 3:
          title = "Profile";
          iconWidget = Image.asset(AppImage.profile,height: 20,);
          break;
        default:
          title = "Home";
          iconWidget =  const Icon(Icons.home, size: 24);
      }

      return PersistentBottomNavBarItem(
        icon: Obx(() {
          final isSelected = bottomBarController.selectedIndex.value == index;
          return ColorFiltered(
            colorFilter: ColorFilter.mode(
              isSelected ? AppColor.blue : Colors.grey,
              BlendMode.srcIn,
            ),
            child:iconWidget,
          );
        }),
        title: title,
        activeColorPrimary: AppColor.blue,
        inactiveColorPrimary: Colors.grey,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return PersistentTabView(
      context,
      controller: _controller,
      screens: _buildScreens(),
      items: _navBarsItems(),
      confineToSafeArea: true,
      navBarHeight: kBottomNavigationBarHeight,
      margin: EdgeInsets.zero,
      padding: EdgeInsets.zero,
      backgroundColor: AppColor.white,
      handleAndroidBackButtonPress: true,
      resizeToAvoidBottomInset: true,
      stateManagement: true,
      navBarStyle: NavBarStyle.style9,
      onItemSelected: (index) {
        bottomBarController.changeTabIndex(index);
        callApiOnIndexChange(index);

      },
    );
  }
}


// class HomeScreen  extends StatelessWidget {
//   const HomeScreen({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return const Center(child: Text("Search Screen"));
//   }
// }


import 'package:base_code/data/model/holding_data.dart';
import 'package:base_code/data/model/position_data.dart';
import 'package:base_code/data/network/api_client.dart';
import 'package:base_code/data/network/dio_client.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';
class PortfolioController extends GetxController {
  final GlobalController globalController = Get.find<GlobalController>();
  RxList<HoldingAllData> holdingsData = <HoldingAllData>[].obs;
  RxList<InstrumentData> positionsData = <InstrumentData>[].obs;
  Future<void> fetchPortfolioData(String type) async {
    try {
      final response = await callApi(dio.get('https://serve.indifunded.com/api/portfolio?type=$type'),false);
      if (response?.statusCode == 200) {
        if (type == "holding") {
          HoldingData watchListData = HoldingData.fromJson(response?.data);
holdingsData.clear();
            holdingsData.addAll(watchListData.data!);
            List<int> tokens = watchListData.data!.map((e) => e.instrumentId ?? 0).toList();
            globalController.subscribeToTokens(tokens);
        } else if (type == "position") {
          positionsData.clear();
          PositionData watchListData = PositionData.fromJson(response?.data);
            positionsData.addAll(watchListData.data);
            List<int> tokens = watchListData.data.map((e) => e.instrumentId ).toList();
            globalController.subscribeToTokens(tokens);
        }
      }
    } catch (e) {
      print("Error fetching portfolio data: $e");
    }
  }
  double todayCalculatePercentage(int instrumentId, double invested, int quantity) {
    double lastTradedPrice = globalController.marketPrices[instrumentId] ?? 0.0;
    double closeTradedPrice = globalController.marketClosePrices[instrumentId] ?? 0.0;

    if (closeTradedPrice == 0.0) return 0.0;  // Prevent division by zero

    return ((lastTradedPrice - closeTradedPrice) / closeTradedPrice) * 100;
  }
  double todayCalculateDifference(int instrumentId, double invested, int quantity) {
    double lastTradedPrice = globalController.marketPrices[instrumentId] ?? 0.0;

    return invested - (lastTradedPrice * quantity);
  }

  double calculateDifference(int instrumentId, double invested, int quantity) {
    double lastTradedPrice = globalController.marketPrices[instrumentId] ?? 0.0;

    double totalCurrentValue = lastTradedPrice * quantity; // Current market value
    return totalCurrentValue - invested; // Profit/Loss
  }

  /// Calculate the percentage P&L
  double calculatePercentage(int instrumentId, double invested, int quantity) {
    if (invested == 0.0) return 0.0; // Avoid division by zero

    double difference = calculateDifference(instrumentId, invested, quantity);
    return (difference / invested) * 100; // Percentage change
  }

  /// Calculate today's profit/loss and percentage change
  Map<String, double> calculateHoldingTodayPnL(List<HoldingAllData> data) {
    double totalPnL = 0.0;
    double totalInvestment = 0.0;

    for (var stock in data) {
      double marketPrice = globalController.marketPrices[stock.instrumentId] ?? 0.0;
      double closePrice = globalController.marketClosePrices[stock.instrumentId] ?? 0.0;
      double difference = marketPrice - closePrice;

      totalPnL += difference;  // Sum up total profit/loss
      totalInvestment += closePrice; // Track total previous value
    }

    double percentageChange = (totalInvestment > 0) ? (totalPnL / totalInvestment) * 100 : 0.0;

    return {
      "pnl": totalPnL,
      "percentage": percentageChange,
    };


  }
  double calculatePositionTodayPnL(List<InstrumentData> data) {
    return data.fold(0.0, (sum, stock) {
      double marketPrice = globalController.marketPrices[stock.instrumentId] ?? 0.0;
      double avgPrice = double.tryParse(stock.price) ?? 0.0; // Convert String to double safely

      double difference = (marketPrice - avgPrice);
      int lotSize = 1;
      if (stock.name.startsWith("NIFTY") && (stock.name.endsWith("CE") || stock.name.endsWith("PE"))) {
        lotSize = 75;
      } else if (stock.name.startsWith("BANKNIFTY") && (stock.name.endsWith("CE") || stock.name.endsWith("PE"))) {
        lotSize = 30;
      }


      double totalPl = difference * stock.quantity * lotSize;
      return sum + totalPl;
    });
  }
  @override
  void onInit() {
    super.onInit();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      fetchPortfolioData("holding");
      fetchPortfolioData("position");
    });
  }
}

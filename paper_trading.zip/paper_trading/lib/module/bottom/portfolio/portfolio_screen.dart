import 'package:base_code/data/model/holding_data.dart';
import 'package:base_code/data/model/position_data.dart';
import 'package:base_code/module/bottom/portfolio/portfolio_controller.dart';
import 'package:base_code/module/bottom/stock%20trading/stock_trading_screen.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class PortfolioScreen extends StatefulWidget {
  const PortfolioScreen({super.key});
  @override
  State<PortfolioScreen> createState() => _PortfolioScreenState();
}
class _PortfolioScreenState extends State<PortfolioScreen> {
  final controller = Get.find<PortfolioController>();
  Future<void> _onRefresh() async {
    // Logic to refresh data, for example:
    await controller.fetchPortfolioData("holding");
    await controller.fetchPortfolioData("position");

  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          elevation: 1,
          title: Obx(
            ()=> Text(
              "Portfolio",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: AppPref().isDarkRx.value ? AppColor.greenColor : AppColor.blue,// adjust as needed
                fontSize: 20,
              ),
            ),
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(48.0),
            child: Obx(() => TabBar(
              labelColor: AppPref().isDarkRx.value ? AppColor.greenColor : AppColor.blue,
              unselectedLabelColor: AppPref().isDarkRx.value ? AppColor.white : AppColor.black,
              indicatorColor: AppPref().isDarkRx.value ? AppColor.greenColor : AppColor.blue,

              tabs: [
                // Holdings Tab
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text("Holdings"),
                      const SizedBox(width: 6), // Spacing
                      Obx(() {
                        int holdingsCount = controller.holdingsData.length;
                        return holdingsCount > 0
                            ? Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            color: AppColor.blue, // Badge background color
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            holdingsCount.toString(),
                            style: const TextStyle(
                              color: Colors.white, // Text color
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        )
                            : const SizedBox(); // Hide badge if count is 0
                      }),
                    ],
                  ),
                ),

                // Positions Tab
                Tab(
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text("Positions"),
                      const SizedBox(width: 6), // Spacing
                      Obx(() {
                        int positionsCount = controller.positionsData.length;
                        return positionsCount > 0
                            ? Container(
                          padding: const EdgeInsets.all(6),
                          decoration: const BoxDecoration(
                            color: AppColor.blue, // Badge background color
                            shape: BoxShape.circle,
                          ),
                          child: Text(
                            positionsCount.toString(),
                            style: const TextStyle(
                              color: Colors.white, // Text color
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        )
                            : const SizedBox(); // Hide badge if count is 0
                      }),
                    ],
                  ),
                ),
              ],

            )),
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: TabBarView(
                children: [
                  RefreshIndicator(
                    onRefresh: _onRefresh,
                    child: Column(
                      children: [
                        Obx(() => _buildSummaryContainer(controller.holdingsData)),
                        Expanded(child: Obx(() => _buildListView(controller.holdingsData    ))),
                        Obx(() {
                          Map<String, double> pnlData = controller.calculateHoldingTodayPnL(controller.holdingsData);
                          double todayPnL = pnlData["pnl"]!;
                          double percentageChange = pnlData["percentage"]!;
                          bool isPositive = todayPnL >= 0;
                          return Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(16),
                            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              border: Border.all(color: isPositive ? Colors.green : Colors.red),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                Text(
                                  "Today P&L",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w400,
                                    color: isPositive ? Colors.green : Colors.red,
                                  ),
                                ),
                                Text(
                                  " ${isPositive?"+":""}${todayPnL.toStringAsFixed(2)} (${percentageChange.toStringAsFixed(2)}%)",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: isPositive ? Colors.green : Colors.red,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
                  ),
                  RefreshIndicator(
                    onRefresh: _onRefresh,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start, // Ensure left alignment

                      children: [
                        Obx(() {
                          double todayPnL = controller.calculatePositionTodayPnL(controller.positionsData);

                          bool isPositive = todayPnL >= 0;
                          return Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(16),
                            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              border: Border.all(color: isPositive ? Colors.green : Colors.red),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [

                                const SizedBox(width: 5),
                                Text(
                                  "Total P&L",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: isPositive ? Colors.green : Colors.red,
                                  ),
                                ),   Text(

                                  "${isPositive?"+":""} ${todayPnL.toStringAsFixed(2)}",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: isPositive ? Colors.green : Colors.red,
                                  ),
                                ),

                              ],
                            ),
                          );
                        }),
                        // Ensure the list view takes all available space first
                        Expanded(
                          child: Obx(() {
                            return controller.positionsData.isNotEmpty
                                ? _buildPositionListView(controller.positionsData)
                                : const Center(child: Text("No Positions Available")); // Handle empty case
                          }),
                        ),

                      ],
                    ),
                  ),

                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
  Widget _buildSummaryContainer(RxList<HoldingAllData> data) {
    double totalInvestment = data.fold(0.0, (total, stock) {
      int effectiveQuantity = (stock.instrumentType == "PE" || stock.instrumentType == "CE")
          ? (stock.quantity ?? 0) * (stock.totalLot ?? 1)
          : (stock.quantity ?? 0);

      return total + (double.parse(stock.price ?? '0.0') * effectiveQuantity);
    });


    double currentInvestment = data.fold(0.0, (total, stock) {

      int effectiveQuantity = (stock.quantity ?? 0) * ((stock.totalLot ?? 1) == 0 ? 1 : stock.totalLot!);


      double currentPrice = Get.find<GlobalController>().marketPrices[stock.instrumentId] ?? 0.0;

      return total + (currentPrice * effectiveQuantity);
    });


    double profitOrLoss = currentInvestment - totalInvestment;
    bool isPositive = profitOrLoss >= 0;
    double percentage = totalInvestment == 0.0 ? 0.0 : (profitOrLoss / totalInvestment) * 100;

    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white),
          color: Colors.white
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text("Invested",style: const TextStyle().textColor(AppColor.black),),
                  Text(totalInvestment.toStringAsFixed(2), style: const TextStyle().textColor(AppColor.black).normal18w400),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text("Current",style: const TextStyle().textColor(AppColor.black),),
                  Text(currentInvestment.toStringAsFixed(2), style: const TextStyle().textColor(AppColor.black).normal18w400),
                ],
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Divider(),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
               Text("P&L",style: const TextStyle().textColor(AppColor.black).normal18w400,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [


                      Column(
                        children: [
                          Text(
                            "${isPositive ? '+' : ''}${profitOrLoss.toStringAsFixed(2)}",
                            style: TextStyle(color: isPositive ? Colors.green : Colors.red).normal18w400,
                          ),
                          const SizedBox(width: 6),
                          Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Text(
                              "${isPositive ? '+' : ''}${percentage.toStringAsFixed(2)}%",
                              style: TextStyle(color: isPositive ? Colors.green : Colors.red),
                            ),
                          ),
                        ],
                      ),

                    ],
                  )
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
  Widget _buildListView(RxList<HoldingAllData> data) {
    return ListView.builder(
      itemCount: data.length,
      itemBuilder: (context, index) {
        final stock = data[index];
        return _buildStockItem(stock);
      },
    );
  }

  Widget _buildStockItem(HoldingAllData stock) {
    final GlobalController globalController = Get.find<GlobalController>();

    int instrumentId = stock.instrumentId!;
    return Obx(() {
      int effectiveQuantity = (stock.instrumentType == "PE" || stock.instrumentType == "CE")
          ? (stock.quantity ?? 0) * ((stock.totalLot ?? 1) == 0 ? 1 : stock.totalLot!)
          : (stock.quantity ?? 0);


      double invested = effectiveQuantity * (double.tryParse(stock.price ?? "0") ?? 0.0);

      double lastTradedPrice = globalController.marketPrices[instrumentId] ?? 0.0;
      double percentage = controller.calculatePercentage(instrumentId,invested,effectiveQuantity);
      double todayPercentage = controller.todayCalculatePercentage(instrumentId,invested,effectiveQuantity);
      double difference = controller.calculateDifference(instrumentId,invested,effectiveQuantity,);
      bool isPositive = difference >= 0;
      bool isTodayPositive = todayPercentage >= 0;

      return Padding(
        padding: const EdgeInsets.only(right: 12.0, left: 12,top: 12),
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: (){
            showStockBottomSheet(context,stock);
          },
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Text(stock.quantity?.toString() ?? "", style: const TextStyle().normal12w300,),
                            const Gap(4),

                             Text(stock.instrumentType=="EQ"?"Qty":"Lot",style: const TextStyle().normal14w500,),

                            const Gap(4),
                            const Text("•", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            const Gap(4),
                            const Text("Avg",),
                            const Gap(4),
                            Text(
                              double.tryParse(stock.price ?? "0")?.toStringAsFixed(2) ?? "0.00",
                              style: const TextStyle().normal14w500,
                            ),
                          ],
                        ),
                        Text(
                         " ${isPositive ? '+' : ''}${percentage.toStringAsFixed(2)}${"%"}",

                          style: const TextStyle().normal12w500.textColor(isPositive ? AppColor.greenColor : AppColor.redColor),
                        ),
                      ],
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(stock.name?.toString() ?? "", style: const TextStyle().normal14w600,),
                          Text(
                            "${isPositive ? '+' : ''}${difference.toStringAsFixed(2)}",
                            style: const TextStyle().normal12w500.textColor(isPositive ? AppColor.greenColor : AppColor.redColor),
                          ),
                        ],
                      ),
                    ),
                    const Gap(4), SizedBox(
                      width: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              const Text("Invested"),
                              const Gap(4),
                              Text(invested.toStringAsFixed(2), style: const TextStyle().normal14w500,),
                            ],
                          ),
                          Row(
                            children: [
                              Text("LTP ${lastTradedPrice.toStringAsFixed(2)}", style: const TextStyle().normal12w400,),
                              Text(" (${todayPercentage.toStringAsFixed(2)})", style: const TextStyle().normal12w400.textColor(isTodayPositive?AppColor.greenColor : AppColor.redColor),),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const Divider(),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    });
  }

  void showStockBottomSheet(BuildContext context, HoldingAllData  stock) {
    int token = stock.instrumentId??0;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return Obx(() {
          double? livePrice = Get.find<GlobalController>().marketPrices[token];
          double? baseline = Get.find<GlobalController>().marketClosePrices[token];
          String displayValue = livePrice != null ? livePrice.toStringAsFixed(2) : "Fetching...";
          String changeText = "";
          Color changeColor = Colors.black;
          if (livePrice != null && baseline != null && baseline > 0) {
            double diff = livePrice - baseline;
            double perc = (diff / baseline) * 100;
            changeText =
            "${diff >= 0 ? '+' : ''}${diff.toStringAsFixed(2)} (${perc >= 0 ? '+' : ''}${perc.toStringAsFixed(2)}%)";
            changeColor = diff >= 0 ? Colors.green : Colors.red;
          }
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Stock Name
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    stock.name ?? '',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 4),
                // Stock Price & Change
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    RichText(
                      text: TextSpan(
                        style: const TextStyle(fontSize: 16, color: Colors.black),
                        children: [
                          TextSpan(
                            text: "$displayValue ",
                            style: TextStyle(
                                fontWeight: FontWeight.bold, color: changeColor),
                          ),
                          TextSpan(
                            text: changeText,
                            style: TextStyle(color: changeColor),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Get.to(() => const StockTradingScreen(),
                            arguments: {
                              'title': stock.tradingsymbol ?? '',
                              'livePrice': livePrice ?? 0.0,
                              'token': token,
                              'orderType': 'BUY',
                              'instrument_type': stock.instrumentType,

                            },
                          );
                          Navigator.pop(context);

                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("BUY",
                            style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Get.to(() => const StockTradingScreen(),
                            arguments: {
                              'title': stock.tradingsymbol ?? '',
                              'livePrice': livePrice ?? 0.0,
                              'token': token,
                              'orderType': 'SELL', // Pass SELL Type
                              'instrument_type': stock.instrumentType,

                            },
                          );
                  Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("SELL",
                            style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: () {
                    Get.toNamed(AppRouter.chartScreen, arguments: {
                      'token': token,
                    });
                  },
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.bar_chart, color: Colors.blue),
                      SizedBox(width: 5),
                      Text("View chart", style: TextStyle(color: Colors.blue, fontSize: 16)),
                      SizedBox(width: 5),
                      Icon(Icons.arrow_forward, color: Colors.blue),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          );
        });
      },
    );
  }

  Widget _buildPositionListView(List<InstrumentData> data) {


    return  ListView.builder(
      itemCount: data.length,
      itemBuilder: (context, index) {
        final stock = data[index];
        return _buildPositionStockItem(stock);
      },
    );
  }

  Widget _buildPositionStockItem(InstrumentData stock) {
    int instrumentId = stock.instrumentId;
    return Obx(() {
      double lastTradedPrice = controller.globalController.marketPrices[instrumentId] ?? 0.0;
      int effectiveQuantity = (stock.instrumentType == "PE" || stock.instrumentType == "CE")
          ? (stock.quantity ) * ((stock.totalLot ?? 1) == 0 ? 1 : stock.totalLot!)
          : (stock.quantity );


      double invested = effectiveQuantity * (double.tryParse(stock.price ?? "0") ?? 0.0);


     // double percentage = controller.calculatePercentage(instrumentId,invested);
      double difference = controller.calculateDifference(instrumentId,invested,effectiveQuantity);
      bool isPositive = difference >= 0;
      return Padding(
        padding: const EdgeInsets.only(right: 12.0, left: 12,top: 12),
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: (){
            showStockBottomPositionSheet(context,stock);
          },
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Text(stock.quantity.toString() , style: const TextStyle().normal12w500,),
                            const Gap(4),
                             Text(stock.instrumentType=="EQ"?"Qty":"Lot"),
                            const Gap(4),
                            const Text("•", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            const Gap(4),
                            const Text("Avg"),
                            const Gap(4),
                            Text(
                              double.tryParse(stock.price )?.toStringAsFixed(2) ?? "0.00",
                              style: const TextStyle().normal12w500,
                            ),
                          ],
                        ),
                        // Text(
                        //   percentage.t,
                        //   style: const TextStyle().normal12w500.textColor(isPositive ? AppColor.greenColor : AppColor.redColor),
                        // ),
                      ],
                    ),
                    SizedBox(
                      width: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(stock.name.toString() , style: const TextStyle().normal14w600,),
                          Text("${isPositive ? '+' : ''}${difference.toStringAsFixed(2)}", style: const TextStyle().normal13w500.textColor(isPositive ? AppColor.greenColor : AppColor.redColor),),
                        ],
                      ),
                    ),
                    const Gap(4), SizedBox(
                      width: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Text(stock.exchange, style: const TextStyle().normal12w500,),

                            ],
                          ),
                          Text(lastTradedPrice.toStringAsFixed(2), style: const TextStyle().normal12w500,),
                        ],
                      ),
                    ),
                    const Divider(),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    });
  }

  void showStockBottomPositionSheet(BuildContext context, InstrumentData  stock) {
    int token = stock.instrumentId;
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return Obx(() {
          double? livePrice = Get.find<GlobalController>().marketPrices[token];
          double? baseline = Get.find<GlobalController>().marketClosePrices[token];
          String displayValue = livePrice != null ? livePrice.toStringAsFixed(2) : "Fetching...";
          String changeText = "";
          Color changeColor = Colors.black;
          if (livePrice != null && baseline != null && baseline > 0) {
            double diff = livePrice - baseline;
            double perc = (diff / baseline) * 100;
            changeText =
            "${diff >= 0 ? '+' : ''}${diff.toStringAsFixed(2)} (${perc >= 0 ? '+' : ''}${perc.toStringAsFixed(2)}%)";
            changeColor = diff >= 0 ? Colors.green : Colors.red;
          }
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Stock Name
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    stock.tradingSymbol ,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 4),
                // Stock Price & Change
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    RichText(
                      text: TextSpan(
                        style: const TextStyle(fontSize: 16, color: Colors.black),
                        children: [
                          TextSpan(
                            text: displayValue,
                            style: TextStyle(
                                fontWeight: FontWeight.bold, color: changeColor),
                          ),
                          TextSpan(
                            text: changeText,
                            style: TextStyle(color: changeColor),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Get.to(() => const StockTradingScreen(),
                            arguments: {
                              'title': stock.tradingSymbol ,
                              'livePrice': livePrice ?? 0.0,
                              'token': token,
                              'orderType': 'BUY',
                              'instrument_type': stock.instrumentType,

                            },
                          );
                          Navigator.pop(context);

                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("BUY",
                            style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          Get.to(() => const StockTradingScreen(),
                            arguments: {
                              'title': stock.tradingSymbol ,
                              'livePrice': livePrice ?? 0.0,
                              'token': token,
                              'orderType': 'SELL', // Pass SELL Type
                              'instrument_type': stock.instrumentType,

                            },
                          );
                  Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: const Text("SELL",
                            style: TextStyle(fontSize: 16, color: Colors.white)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: () {
                    Get.toNamed(AppRouter.chartScreen, arguments: {
                      'token': token,
                    });
                  },
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.bar_chart, color: Colors.blue),
                      SizedBox(width: 5),
                      Text("View chart", style: TextStyle(color: Colors.blue, fontSize: 16)),
                      SizedBox(width: 5),
                      Icon(Icons.arrow_forward, color: Colors.blue),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],
            ),
          );
        });
      },
    );
  }
}


// import 'package:base_code/data/model/search_data.dart';
// import 'package:base_code/module/bottom/stock%20trading/stock_trading_screen.dart';
// import 'package:base_code/module/home/home_controller.dart';
// import 'package:base_code/package/config_packages.dart';
// import 'package:base_code/package/screen_packages.dart';
//
// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});
//
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
 // final GlobalController globalController = Get.find<GlobalController>();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Padding(
//         padding: const EdgeInsets.all(12.0),
//         child: SingleChildScrollView(
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Center(
//                 child: Image.asset(
//                   AppImage.splashIcon,
//                   width: 180,
//                 ),
//               ),
//               CommonTextField(
//                 controller: homeController.textEditingController.value,
//                 prefixIcon: Icon(Icons.search, color: AppColor.blackWhite()),
//
//                 hintText: "Search & add",
//               ),
//               Obx(() {
//                 if (homeController.searchQuery.value.isEmpty) {
//                   return const SizedBox();
//                 }
//
//                 return ListView.builder(
//                   shrinkWrap: true,
//                   physics: const NeverScrollableScrollPhysics(),
//                   itemCount: homeController.searchResults.length,
//                   itemBuilder: (context, index) {
//                     SearchAllData data = homeController.searchResults[index];
//                     return Card(
//                       margin: const EdgeInsets.symmetric(vertical: 4),
//                       child: InkWell(
//                         onTap: (){
//                           print("Tapped on: ${data.name}");
//                           Get.back();
//
//                           showStockBottomSheet(context, data);
//
//                         },
//                         child: ListTile(
//
//                           leading: Container(
//                             decoration: BoxDecoration(
//                               color: Colors.grey[200],
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//                             padding: const EdgeInsets.all(8),
//                             child: Text(data.exchange ?? ''),
//                           ),
//                           title: Text(data.name ?? ''),
//                           subtitle: Text(data.tradingsymbol ?? ''),
//                           trailing: GestureDetector(
//                               onTap: (){
//                                 _showWishlistDialog(data.instrumentToken);
//
//                               },
//                               child: const Icon(Icons.add)),
//                           onTap: () {
//                           },
//                         ),
//                       ),
//                     );
//                   },
//                 );
//
//               }
//
//               ),
//               Card(
//                 color: Colors.white,
//                 child: Padding(
//                   padding: const EdgeInsets.only(
//                       right: 12.0, left: 12, top: 12, bottom: 12),
//                   child: Column(
//                     children: [
//                       Row(
//                         children: [
//                           Text(
//                             "Market Today",
//                             style: const TextStyle()
//                                 .normal14w500
//                                 .textColor(AppColor.black),
//                           ),
//                           const Gap(4),
//                           const Icon(
//                             Icons.arrow_forward_ios_rounded,
//                             color: AppColor.black,
//                             size: 15,
//                           ),
//                         ],
//                       ),
//                       const SizedBox(height: 18),
//                       Obx(
//                             () => SizedBox(
//                           height: 100,
//                           child: ListView.builder(
//                             scrollDirection: Axis.horizontal,
//                             itemCount: homeController.instrumentTokens.keys.length,
//                             itemBuilder: (context, index) {
//                               String title = homeController.instrumentTokens.keys.elementAt(index);
//                               int? token = homeController.instrumentTokens[title];
//
//                               return Obx(() {
//                                 double? livePrice = globalController.marketPrices[token];
//                                 double? baseline = globalController.marketClosePrices[token];
//                                 String displayValue = livePrice != null ? livePrice.toStringAsFixed(2) : "Fetching...";
//                                 String changeText = "";
//                                 Color changeColor = Colors.black;
//
//                                 if (livePrice != null && baseline != null && baseline > 0) {
//                                   double diff = livePrice - baseline;
//                                   double perc = (diff / baseline) * 100;
//                                   changeText = "${diff >= 0 ? '+' : ''}${diff.toStringAsFixed(2)} (${perc >= 0 ? '+' : ''}${perc.toStringAsFixed(2)}%)";
//                                   changeColor = diff >= 0 ? Colors.green : Colors.red;
//                                 }
//
//                                 return Padding(
//                                   padding: const EdgeInsets.only(right: 8.0),
//                                   child: GestureDetector(
//                                     onTap: () {
//                                       Get.back();
//
//                                       Data stockData = Data(
//                                         instrumentToken: token,
//                                         name: title,
//                                         exchange: "NSE",
//                                       );
//                                       showStockBottomSheet(context, stockData);
//                                     },
//                                     child: MarketCard(
//                                       title: title,
//                                       value: displayValue,
//                                       change: changeText,
//                                       changeColor: changeColor,
//                                     ),
//                                   ),
//                                 );
//                               });
//                             },
//                           ),
//                         ),
//                       )
//
//                     ],
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//   void _showWishlistDialog(int? instrumentToken) {
//     Get.defaultDialog(
//       title: "Add to Wishlist",
//       content: Column(
//         children: List.generate(3, (index) {
//           String wishlistName = "Watchlist ${index + 1}";
//           return ListTile(
//             title: Text(wishlistName),
//             onTap: () {
//               homeController.addToWishlist(wishlistName, instrumentToken);
//               Get.back();
//             },
//           );
//         }),
//       ),
//     );
//   }
// }
// void showStockBottomSheet(BuildContext context, Data stock) {
//   int token = stock.instrumentToken!;
//   showModalBottomSheet(
//     context: context,
//     shape: const RoundedRectangleBorder(
//       borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
//     ),
//     builder: (context) {
//       return Obx(() {
//         double? livePrice = Get.find<GlobalController>().marketPrices[token];
//         double? baseline = Get.find<GlobalController>().marketClosePrices[token];
//         String displayValue = livePrice != null ? livePrice.toStringAsFixed(2) : "Fetching...";
//         String changeText = "";
//         Color changeColor = Colors.black;
//
//         if (livePrice != null && baseline != null && baseline > 0) {
//           double diff = livePrice - baseline;
//           double perc = (diff / baseline) * 100;
//           changeText =
//           "${diff >= 0 ? '+' : ''}${diff.toStringAsFixed(2)} (${perc >= 0 ? '+' : ''}${perc.toStringAsFixed(2)}%)";
//           changeColor = diff >= 0 ? Colors.green : Colors.red;
//         }
//
//         return Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               // Stock Name
//               Align(
//                 alignment: Alignment.centerLeft,
//                 child: Text(
//                   stock.name ?? '',
//                   style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//                 ),
//               ),
//               const SizedBox(height: 4),
//               // Stock Price & Change
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(
//                     stock.exchange ?? '',
//                     style: const TextStyle(fontSize: 16, color: Colors.grey),
//                   ),
//                   RichText(
//                     text: TextSpan(
//                       style: const TextStyle(fontSize: 16, color: Colors.black),
//                       children: [
//                         TextSpan(
//                           text: "$displayValue ",
//                           style: TextStyle(
//                               fontWeight: FontWeight.bold, color: changeColor),
//                         ),
//                         TextSpan(
//                           text: changeText,
//                           style: TextStyle(color: changeColor),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 16),
//               // Buy & Sell Buttons
//               Row(
//                 children: [
//                   Expanded(
//                     child: ElevatedButton(
//                       onPressed: () {
//                         Get.to(
//                               () => const StockTradingScreen(),
//                           arguments: {
//                             'title': stock.name ?? '',
//                             'livePrice': livePrice ?? 0.0,
//                             'token': token,
//                             'orderType': 'BUY', // Pass BUY Type
//                           },
//                         );
//                         Navigator.pop(context);
//
//                       },
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.blue,
//                         padding: const EdgeInsets.symmetric(vertical: 14),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(8),
//                         ),
//                       ),
//                       child: const Text("BUY",
//                           style: TextStyle(fontSize: 16, color: Colors.white)),
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   Expanded(
//                     child: ElevatedButton(
//                       onPressed: () {
//                         Get.to(
//                               () => const StockTradingScreen(),
//                           arguments: {
//                             'title': stock.name ?? '',
//                             'livePrice': livePrice ?? 0.0,
//                             'token': token,
//                             'orderType': 'SELL', // Pass SELL Type
//                           },
//                         );
//                         Navigator.pop(context);
//
//                       },
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.red,
//                         padding: const EdgeInsets.symmetric(vertical: 14),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(8),
//                         ),
//                       ),
//                       child: const Text("SELL",
//                           style: TextStyle(fontSize: 16, color: Colors.white)),
//                     ),
//                   ),
//                 ],
//               ),
//               const SizedBox(height: 16),
//               GestureDetector(
//                   onTap: () {
//                     Get.toNamed(AppRouter.chartScreen, arguments: {
//                       'token': token,
//                     });
//                   },
//                 child: const Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Icon(Icons.bar_chart, color: Colors.blue),
//                     SizedBox(width: 5),
//                     Text("View chart",
//                         style: TextStyle(color: Colors.blue, fontSize: 16)),
//                     SizedBox(width: 5),
//                     Icon(Icons.arrow_forward, color: Colors.blue),
//                   ],
//                 ),
//               ),
//               const SizedBox(height: 8),
//             ],
//           ),
//         );
//       });
//     },
//   );
// }
//
// class MarketCard extends StatelessWidget {
//   final String title;
//   final String value;
//   final String change;
//   final Color changeColor;
//   final String? tag;
//
//   const MarketCard({
//     super.key,
//     required this.title,
//     required this.value,
//     required this.change,
//     required this.changeColor,
//     this.tag,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: 220,
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(
//           color: Colors.black,
//           width: 1.5,
//         ),
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(12.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Text(
//                   title,
//                   style: const TextStyle(
//                     fontSize: 14,
//                     fontWeight: FontWeight.w500,
//                     color: Colors.black,
//                   ),
//                 ),
//                 if (tag != null)
//                   Padding(
//                     padding: const EdgeInsets.only(left: 8.0),
//                     child: Container(
//                       padding: const EdgeInsets.symmetric(
//                         horizontal: 6,
//                         vertical: 2,
//                       ),
//                       decoration: BoxDecoration(
//                         color: Colors.green,
//                         borderRadius: BorderRadius.circular(4),
//                       ),
//                       child: Text(
//                         tag!,
//                         style: const TextStyle(
//                           fontSize: 10,
//                           color: Colors.white,
//                         ),
//                       ),
//                     ),
//                   ),
//               ],
//             ),
//             const SizedBox(height: 8),
//             Text(
//               value,
//               style: const TextStyle(
//                 fontSize: 16,
//                 fontWeight: FontWeight.w600,
//                 color: Colors.black,
//               ),
//             ),
//             const SizedBox(height: 4),
//             Text(
//               change,
//               style: TextStyle(
//                 fontSize: 12,
//                 color: changeColor,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// class StockCard extends StatelessWidget {
//   final String name;
//   final String price;
//   final String change;
//   final Color changeColor;
//   final String recentBuys;
//   final String logoAsset;
//
//   const StockCard({
//     super.key,
//     required this.name,
//     required this.price,
//     required this.change,
//     required this.changeColor,
//     required this.recentBuys,
//     required this.logoAsset, // Updated to accept asset path
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: 200, // Adjust width to fit the card
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(
//           color: Colors.black,
//           width: 1.5,
//         ),
//       ),
//       child: Padding(
//         padding: const EdgeInsets.all(12.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // Logo Row
//             Row(
//               children: [
//                 ClipRRect(
//                   borderRadius: BorderRadius.circular(4),
//                   child: Image.asset(
//                     logoAsset, // Using Image.asset
//                     width: 40,
//                     height: 40,
//                     fit: BoxFit.cover,
//                   ),
//                 ),
//                 const SizedBox(width: 8),
//                 Expanded(
//                   child: Text(
//                     name,
//                     style: const TextStyle(
//                       fontSize: 14,
//                       fontWeight: FontWeight.bold,
//                     ).textColor(AppColor.black),
//                     maxLines: 1,
//                     overflow: TextOverflow.ellipsis,
//                   ),
//                 ),
//               ],
//             ),
//             const SizedBox(height: 8),
//             Text(
//               price,
//               style: const TextStyle(
//                 fontSize: 16,
//                 fontWeight: FontWeight.bold,
//               ).textColor(AppColor.black),
//             ),
//             const SizedBox(height: 4),
//             Text(
//               change,
//               style: TextStyle(
//                 fontSize: 12,
//                 color: changeColor,
//               ),
//             ),
//             const Spacer(),
//             Row(
//               children: [
//                 const Icon(
//                   Icons.shopping_cart,
//                   color: Colors.grey,
//                   size: 16,
//                 ),
//                 const SizedBox(width: 4),
//                 Expanded(
//                   child: Text(
//                     recentBuys,
//                     style: const TextStyle(
//                       fontSize: 12,
//                       color: Colors.grey,
//                     ),
//                     maxLines: 1,
//                     overflow: TextOverflow.ellipsis,
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
//

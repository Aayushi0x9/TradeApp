import 'package:base_code/data/model/holding_data.dart';
import 'package:base_code/data/model/position_data.dart';
import 'package:base_code/data/model/search_data.dart';
import 'package:base_code/data/network/api_client.dart';
import 'package:base_code/data/network/dio_client.dart';
import 'package:base_code/module/bottom/watchlist/watchlist_controller.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';


class HomeController extends GetxController {
  RxMap<String, int> instrumentTokens = <String, int>{}.obs;
  RxMap<String, double> baselinePrices = <String, double>{}.obs;
  final Rx<TextEditingController> textEditingController = TextEditingController().obs;
  final RxString searchQuery = ''.obs;
  RxList<SearchAllData> searchResults = RxList<SearchAllData>();
  @override
  void onInit() {
    super.onInit();

    textEditingController.value.addListener(() {
      searchQuery.value = textEditingController.value.text;
    });

    debounce<String>(
      searchQuery,
          (query) {
        if (query.isNotEmpty) {
          callSearchApi(query);
        }else {
          searchResults.clear();
        }
      },
      time: const Duration(milliseconds: 500),
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      fetchInstrumentTokens();
      fetchPortfolioData("holding");
      fetchPortfolioData("position");
    });
  }
  Future<void> callSearchApi(String query) async {
    try {
      final response = await callApi(dio.get(
        "https://serve.indifunded.com/api/search?search=$query",
      ), false);

      if (response?.statusCode == 200) {
        final responseData = response?.data;
        SearchData searchData = SearchData.fromJson(responseData);

        if (searchData.data != null) {
          searchResults.clear();
          searchResults.addAll(searchData.data!.map((e) => e).toList());
          searchResults.refresh();
        }
        else {
        }
        searchResults.refresh();
      } else {
      }
    } finally{

    }
  }
  Future<void> addToWishlist(String wishlistName, int? instrumentToken) async {
    if (instrumentToken == null) return;
    try {
      final response = await callApi(dio.post(
        "https://serve.indifunded.com/api/wishlist/$wishlistName/$instrumentToken",
      ),false);
      if (response?.statusCode == 201) {
        final controller = Get.put<WatchListController>(WatchListController());
          controller.fetchAllWatchlists();
      } else {
      }
    } finally{

    }
  }
  RxList<HoldingAllData> holdingsData = <HoldingAllData>[].obs;   // For Holdings Tab
  RxList<InstrumentData> positionsData = <InstrumentData>[].obs;  // For Positions Tab

  Future<void> fetchPortfolioData(String type) async {
    try {
      final response = await callApi(dio.get('https://serve.indifunded.com/api/portfolio?type=$type'),false);
      if (response?.statusCode == 200) {

        if (type == "holding") {
          holdingsData.clear();
          HoldingData watchListData = HoldingData.fromJson(response?.data);

          holdingsData.value = watchListData.data ?? [];
        } else if (type == "position") {
          positionsData.clear();
          PositionData watchListData = PositionData.fromJson(response?.data);

          positionsData.value = watchListData.data ;
        }


      }
    } finally{

    }
  }
  Future<void> fetchInstrumentTokens() async {
    try {
      final response = await callApi(dio.get(
        "https://serve.indifunded.com/api/ohlc?symbols=NSE:NIFTY 50,NSE:NIFTY BANK",
      ),false);

      if (response?.statusCode == 200) {
        final responseData = response?.data;
        final data = responseData['data'] as Map<String, dynamic>;

        int niftyToken = data["NSE:NIFTY 50"]?['instrument_token'] ?? 0;
        double niftyBaseline = (data["NSE:NIFTY 50"]?['last_price'] ?? 0.0).toDouble();

        int bankNiftyToken = data["NSE:NIFTY BANK"]?['instrument_token'] ?? 0;
        double bankNiftyBaseline = (data["NSE:NIFTY BANK"]?['last_price']  ?? 0.0).toDouble();

        instrumentTokens["NIFTY 50"] = niftyToken;
        instrumentTokens["NIFTY BANK"] = bankNiftyToken;
        baselinePrices["NIFTY 50"] = niftyBaseline;
        baselinePrices["NIFTY BANK"] = bankNiftyBaseline;

        GlobalController globalController = Get.find<GlobalController>();
        globalController.subscribeToTokens([niftyToken, bankNiftyToken]);
      } else {
      }
    }finally{

    }
  }
}

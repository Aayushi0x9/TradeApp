import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class SplashController extends GetxController {
  final globalController = Get.find<GlobalController>();

  goNextScreen() async {

    3.delay(() async {
      if(AppPref().isLogin==true){
        Get.offAllNamed(AppRouter.bottomBarScreen );

      }else{
        Get.toNamed(AppRouter.loginScreen );

      }

    });
  }

  @override
  void onReady() {
    super.onReady();
    goNextScreen();
  }
}

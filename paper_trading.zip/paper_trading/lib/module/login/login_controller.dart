import 'package:base_code/data/network/dio_client.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class LoginController extends GetxController{
  RxBool isPasswordHidden = true.obs;
  final Rx<TextEditingController> emailController = TextEditingController().obs;
  final Rx<TextEditingController> passwordController = TextEditingController().obs;
  RxString errorMessage = ''.obs; // Add error message observable

  void togglePasswordVisibility() {
    isPasswordHidden.value = !isPasswordHidden.value;
  }
  Future<void> logInApiCall() async {
    try {
      final requestData = {
        "email":emailController.value.text,
        "password":passwordController.value.text
      };
      final response = await
          dio.post(
            'https://serve.indifunded.com/api/user/login',
            data: requestData,
          );


      if (response.statusCode == 200) {
        Get.find<GlobalController>().connectSocket();

        final responseData = response.data;
        AppPref().token = responseData["data"]["token"];
        AppPref().isLogin=true;
        final GlobalController globalController = Get.find<GlobalController>();
        globalController.connectSocket();
        AppLoader().dismissLoader();
        Get.offAllNamed(AppRouter.bottomBarScreen);
      }  else if(response.statusCode == 401){
        Get.snackbar(
          "Login Failed",
          response.data["message"] ?? "Invalid email or password",
          snackPosition: SnackPosition.TOP,
          backgroundColor: Colors.red,
          colorText: Colors.white,
          duration: const Duration(seconds: 3),
        );
        print("456");
        print({response.data["message"]});
        AppLoader().dismissLoader();
      }
    }on DioException catch (error) {
      Get.snackbar(
        "Login Failed",
        error.response?.data["message"] ?? "Invalid email or password",
        snackPosition: SnackPosition.TOP,
        backgroundColor: Colors.red,
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );

    }
    finally{
      AppLoader().dismissLoader();

    }
  }

}
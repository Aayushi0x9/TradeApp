import 'package:base_code/module/login/login_controller.dart';
import 'package:base_code/package/config_packages.dart';
import 'package:base_code/package/screen_packages.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final LoginController loginController = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15),
            child: Image.asset(
              AppImage.indifunded,
              height: 56,
              width: 56,
            ),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 12.0, right: 12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Login", style: const TextStyle().normal32w600),
            const Gap(35),
            CommonTextField(
              controller: loginController.emailController.value,
              hintText: "User Id",
              suffixIcon: Padding(
                padding: const EdgeInsets.only(right: 19.0),
                child: Image.asset(AppImage.profile, height: 24, width: 24),
              ),
              contentPadding: const EdgeInsets.only(
                  top: 19, bottom: 19, left: 19, right: 19),
            ),
            const Gap(30),
            Obx(() => CommonTextField(
                  controller: loginController.passwordController.value,
                  hintText: "Password",
                  obscureText: loginController.isPasswordHidden.value,
                  // Control visibility
                  contentPadding: const EdgeInsets.only(
                      top: 19, bottom: 19, left: 19, right: 19),
                  suffixIcon: IconButton(
                    icon: Icon(
                      loginController.isPasswordHidden.value
                          ? Icons.visibility_off
                          : Icons.visibility,
                      color: Colors.grey,
                      size: 24,
                    ),
                    padding: const EdgeInsets.only(right: 19.0),
                    onPressed: loginController
                        .togglePasswordVisibility, // Toggle function
                  ),
                )),
            const Gap(30),
            CommonAppButton(
              text: "Login",
              buttonType: ButtonType.enable,
              color: AppColor.blue,
              onTap: () {
                loginController.logInApiCall();
              },
            ),
          ],
        ),
      ),
    );
  }
}

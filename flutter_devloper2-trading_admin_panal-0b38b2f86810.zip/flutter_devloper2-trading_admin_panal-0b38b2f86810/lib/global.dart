import 'package/config_packages.dart';

class GlobalController extends GetxController{}
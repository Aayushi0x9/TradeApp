

class  AppImage{



 static const images = "asset/image/";
 static const dashboard = "${images}bottomBar/";
 static const appLogo = "${images}appLogo/";
 static const icons = "${images}icons/";


// app logo
 static const appIcon = "${appLogo}appLogo.png";
 static const splashIcon = "${appLogo}splash.png";


// dashboard icon


 //icons





}
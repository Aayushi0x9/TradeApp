class FirebaseString {
  FirebaseString._();

  ///firestore collection
  static const user = "user";

}

package com.example.paper_trading_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
